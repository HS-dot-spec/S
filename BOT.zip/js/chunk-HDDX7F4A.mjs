var l = Object.create
  , a = Object.defineProperty
  , n = Object.getOwnPropertyDescriptor
  , f = Object.getOwnPropertyNames
  , O = Object.getPrototypeOf
  , c = Object.prototype.hasOwnProperty
  , u = (r, e) => () => (e || r((e = {
    exports: {}
}).exports, e),
e.exports)
  , s = (r, e, t, p) => {
    if (e && typeof e == "object" || typeof e == "function")
        for (let o of f(e))
            !c.call(r, o) && o !== t && a(r, o, {
                get: () => e[o],
                enumerable: !(p = n(e, o)) || p.enumerable
            });
    return r
}
  , v = (r, e, t) => (t = r != null ? l(O(r)) : {},
s(e || !r || !r.__esModule ? a(t, "default", {
    value: r,
    enumerable: !0
}) : t, r));

export {u as a, v as b};
//# sourceMappingURL=out.js.map
//# sourceMappingURL=chunk-HDDX7F4A.mjs.map
