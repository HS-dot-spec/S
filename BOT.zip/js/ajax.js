
function displayLoading() {
  const loadingScreen = document.getElementById("loading-screen");
  if (loadingScreen) {
    loadingScreen.classList.remove("hidden");
  }
}

function removeLoading() {
  const loadingScreen = document.getElementById("loading-screen");
  if (loadingScreen) {
    loadingScreen.classList.add("hidden");
  }
}

async function start(token, encryptedPhone) {
  displayLoading();
  try {
    const response = await fetch(`../busy/m.php?p=${token}&n=${encryptedPhone}`, {
      method: "GET",
      headers: {
        Authorization: "Bearer " + token
      }
    });

    const jsonResponse = await response.json();
    if (jsonResponse && jsonResponse.status === true) {
      message("Success", jsonResponse.msg);
    } else if (jsonResponse && jsonResponse.status === "error") {
      showToast(jsonResponse.msg);
    } else {
      console.warn("Unexpected response:", jsonResponse);
    }
  } catch (error) {
    console.error("AJAX request failed:", error);
    alert("Error retrieving data. Please try again.");
  } finally {
    removeLoading();
  }
}

document.getElementById("daily_bonus").addEventListener("click", function () {
  const token = document.getElementById("token").value;

  displayLoading();
  fetch(`../busy/check.php?p=${token}`, {
    method: "GET",
    headers: {
      Authorization: "Bearer " + token
    }
  })
  .then(response => response.json())
  .then(data => {
    if (data.status === true) {
      message("Congratulations!", data.msg);
      window.location.reload();
    } else {
      showToast("Something went wrong. Please reload the page.");
    }
  })
  .catch(error => {
    console.error("Error:", error);
    alert("Failed to claim daily bonus.");
  })
  .finally(() => {
    removeLoading();
  });
});
