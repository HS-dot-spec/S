  function toggleMenu() {
    const menu = document.getElementById("menuItems");
    menu.classList.toggle("hidden");
  }
    function toggleMenu() {
      const menuItems = document.getElementById('menuItems');
      const menuIcon = document.getElementById('menuIcon');

      if (menuItems.classList.contains('hidden')) {
        menuItems.classList.remove('hidden');
        setTimeout(() => {
          menuItems.classList.add('active');
        }, 100);
      } else {
        menuItems.classList.remove('active'); 
        setTimeout(() => {
          menuItems.classList.add('hidden');
        }, 300);
      }
    }
  