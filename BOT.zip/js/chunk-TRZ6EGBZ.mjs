var ee = {}
  , Be = function(t, e, i, n, r) {
    var o = new Worker(ee[e] || (ee[e] = URL.createObjectURL(new Blob([t + ';addEventListener("error",function(e){e=e.error;postMessage({$e$:[e.message,e.code,e.stack]})})'],{
        type: "text/javascript"
    }))));
    return o.onmessage = function(a) {
        var l = a.data
          , s = l.$e$;
        if (s) {
            var u = new Error(s[0]);
            u.code = s[1],
            u.stack = s[2],
            r(u, null);
        } else
            r(null, l);
    }
    ,
    o.postMessage(i, n),
    o
}
  , F = Uint8Array
  , Z = Uint16Array
  , le = Int32Array
  , zt = new F([0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0, 0, 0, 0])
  , Dt = new F([0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 0, 0])
  , ue = new F([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15])
  , he = function(t, e) {
    for (var i = new Z(31), n = 0; n < 31; ++n)
        i[n] = e += 1 << t[n - 1];
    for (var r = new le(i[30]), n = 1; n < 30; ++n)
        for (var o = i[n]; o < i[n + 1]; ++o)
            r[o] = o - i[n] << 5 | n;
    return {
        b: i,
        r
    }
}
  , de = he(zt, 2)
  , Ut = de.b
  , Je = de.r;
Ut[28] = 258,
Je[258] = 28;
var Re = he(Dt, 0)
  , ce = Re.b
  , gt = new Z(32768);
for (b = 0; b < 32768; ++b)
    K = (b & 43690) >> 1 | (b & 21845) << 1,
    K = (K & 52428) >> 2 | (K & 13107) << 2,
    K = (K & 61680) >> 4 | (K & 3855) << 4,
    gt[b] = ((K & 65280) >> 8 | (K & 255) << 8) >> 1;
var K, b, rt = function(t, e, i) {
    for (var n = t.length, r = 0, o = new Z(e); r < n; ++r)
        t[r] && ++o[t[r] - 1];
    var a = new Z(e);
    for (r = 1; r < e; ++r)
        a[r] = a[r - 1] + o[r - 1] << 1;
    var l;
    if (i) {
        l = new Z(1 << e);
        var s = 15 - e;
        for (r = 0; r < n; ++r)
            if (t[r])
                for (var u = r << 4 | t[r], d = e - t[r], h = a[t[r] - 1]++ << d, c = h | (1 << d) - 1; h <= c; ++h)
                    l[gt[h] >> s] = u;
    } else
        for (l = new Z(n),
        r = 0; r < n; ++r)
            t[r] && (l[r] = gt[a[t[r] - 1]++] >> 15 - t[r]);
    return l
}, ht = new F(288);
for (b = 0; b < 144; ++b)
    ht[b] = 8;
var b;
for (b = 144; b < 256; ++b)
    ht[b] = 9;
var b;
for (b = 256; b < 280; ++b)
    ht[b] = 7;
var b;
for (b = 280; b < 288; ++b)
    ht[b] = 8;
var b, fe = new F(32);
for (b = 0; b < 32; ++b)
    fe[b] = 5;
var b, pe = rt(ht, 9, 1), me = rt(fe, 5, 1), vt = function(t) {
    for (var e = t[0], i = 1; i < t.length; ++i)
        t[i] > e && (e = t[i]);
    return e
}, V = function(t, e, i) {
    var n = e / 8 | 0;
    return (t[n] | t[n + 1] << 8) >> (e & 7) & i
}, yt = function(t, e) {
    var i = e / 8 | 0;
    return (t[i] | t[i + 1] << 8 | t[i + 2] << 16) >> (e & 7)
}, _e = function(t) {
    return (t + 7) / 8 | 0
}, bt = function(t, e, i) {
    return (e == null || e < 0) && (e = 0),
    (i == null || i > t.length) && (i = t.length),
    new F(t.subarray(e, i))
}, ve = ["unexpected EOF", "invalid block type", "invalid length/literal", "invalid distance", "stream finished", "no stream handler", , "no callback", "invalid UTF-8 data", "extra field too long", "date not in range 1980-2099", "filename too long", "stream finishing", "invalid zip data"], x = function(t, e, i) {
    var n = new Error(e || ve[t]);
    if (n.code = t,
    Error.captureStackTrace && Error.captureStackTrace(n, x),
    !i)
        throw n;
    return n
}, ye = function(t, e, i, n) {
    var r = t.length
      , o = n ? n.length : 0;
    if (!r || e.f && !e.l)
        return i || new F(0);
    var a = !i
      , l = a || e.i != 2
      , s = e.i;
    a && (i = new F(r * 3));
    var u = function(Yt) {
        var Zt = i.length;
        if (Yt > Zt) {
            var te = new F(Math.max(Zt * 2, Yt));
            te.set(i),
            i = te;
        }
    }
      , d = e.f || 0
      , h = e.p || 0
      , c = e.b || 0
      , p = e.l
      , m = e.d
      , f = e.m
      , v = e.n
      , _ = r * 8;
    do {
        if (!p) {
            d = V(t, h, 1);
            var S = V(t, h + 1, 3);
            if (h += 3,
            S)
                if (S == 1)
                    p = pe,
                    m = me,
                    f = 9,
                    v = 5;
                else if (S == 2) {
                    var y = V(t, h, 31) + 257
                      , A = V(t, h + 10, 15) + 4
                      , P = y + V(t, h + 5, 31) + 1;
                    h += 14;
                    for (var N = new F(P), O = new F(19), I = 0; I < A; ++I)
                        O[ue[I]] = V(t, h + I * 3, 7);
                    h += A * 3;
                    for (var T = vt(O), B = (1 << T) - 1, C = rt(O, T, 1), I = 0; I < P; ) {
                        var z = C[V(t, h, B)];
                        h += z & 15;
                        var j = z >> 4;
                        if (j < 16)
                            N[I++] = j;
                        else {
                            var U = 0
                              , E = 0;
                            for (j == 16 ? (E = 3 + V(t, h, 3),
                            h += 2,
                            U = N[I - 1]) : j == 17 ? (E = 3 + V(t, h, 7),
                            h += 3) : j == 18 && (E = 11 + V(t, h, 127),
                            h += 7); E--; )
                                N[I++] = U;
                        }
                    }
                    var Q = N.subarray(0, y)
                      , X = N.subarray(y);
                    f = vt(Q),
                    v = vt(X),
                    p = rt(Q, f, 1),
                    m = rt(X, v, 1);
                } else
                    x(1);
            else {
                var j = _e(h) + 4
                  , Lt = t[j - 4] | t[j - 3] << 8
                  , Ot = j + Lt;
                if (Ot > r) {
                    s && x(0);
                    break
                }
                l && u(c + Lt),
                i.set(t.subarray(j, Ot), c),
                e.b = c += Lt,
                e.p = h = Ot * 8,
                e.f = d;
                continue
            }
            if (h > _) {
                s && x(0);
                break
            }
        }
        l && u(c + 131072);
        for (var Ve = (1 << f) - 1, $e = (1 << v) - 1, Mt = h; ; Mt = h) {
            var U = p[yt(t, h) & Ve]
              , nt = U >> 4;
            if (h += U & 15,
            h > _) {
                s && x(0);
                break
            }
            if (U || x(2),
            nt < 256)
                i[c++] = nt;
            else if (nt == 256) {
                Mt = h,
                p = null;
                break
            } else {
                var Kt = nt - 254;
                if (nt > 264) {
                    var I = nt - 257
                      , lt = zt[I];
                    Kt = V(t, h, (1 << lt) - 1) + Ut[I],
                    h += lt;
                }
                var At = m[yt(t, h) & $e]
                  , Pt = At >> 4;
                At || x(3),
                h += At & 15;
                var X = ce[Pt];
                if (Pt > 3) {
                    var lt = Dt[Pt];
                    X += yt(t, h) & (1 << lt) - 1,
                    h += lt;
                }
                if (h > _) {
                    s && x(0);
                    break
                }
                l && u(c + 131072);
                var Qt = c + Kt;
                if (c < X) {
                    var Xt = o - X
                      , qe = Math.min(X, Qt);
                    for (Xt + c < 0 && x(3); c < qe; ++c)
                        i[c] = n[Xt + c];
                }
                for (; c < Qt; ++c)
                    i[c] = i[c - X];
            }
        }
        e.l = p,
        e.p = Mt,
        e.b = c,
        e.f = d,
        p && (d = 1,
        e.m = f,
        e.d = m,
        e.n = v);
    } while (!d);
    return c != i.length && a ? bt(i, 0, c) : i.subarray(0, c)
}, He = new F(0), We = function(t, e) {
    var i = {};
    for (var n in t)
        i[n] = t[n];
    for (var n in e)
        i[n] = e[n];
    return i
}, ie = function(t, e, i) {
    for (var n = t(), r = t.toString(), o = r.slice(r.indexOf("[") + 1, r.lastIndexOf("]")).replace(/\s+/g, "").split(","), a = 0; a < n.length; ++a) {
        var l = n[a]
          , s = o[a];
        if (typeof l == "function") {
            e += ";" + s + "=";
            var u = l.toString();
            if (l.prototype)
                if (u.indexOf("[native code]") != -1) {
                    var d = u.indexOf(" ", 8) + 1;
                    e += u.slice(d, u.indexOf("(", d));
                } else {
                    e += u;
                    for (var h in l.prototype)
                        e += ";" + s + ".prototype." + h + "=" + l.prototype[h].toString();
                }
            else
                e += u;
        } else
            i[s] = l;
    }
    return e
}, _t = [], Ge = function(t) {
    var e = [];
    for (var i in t)
        t[i].buffer && e.push((t[i] = new t[i].constructor(t[i])).buffer);
    return e
}, Ke = function(t, e, i, n) {
    if (!_t[i]) {
        for (var r = "", o = {}, a = t.length - 1, l = 0; l < a; ++l)
            r = ie(t[l], r, o);
        _t[i] = {
            c: ie(t[a], r, o),
            e: o
        };
    }
    var s = We({}, _t[i].e);
    return Be(_t[i].c + ";onmessage=function(e){for(var k in e.data)self[k]=e.data[k];onmessage=" + e.toString() + "}", i, s, Ge(s), n)
}, Qe = function() {
    return [F, Z, le, zt, Dt, ue, Ut, ce, pe, me, gt, ve, rt, vt, V, yt, _e, bt, x, ye, Vt, ge, be]
}, ge = function(t) {
    return postMessage(t, [t.buffer])
}, be = function(t) {
    return t && {
        out: t.size && new F(t.size),
        dictionary: t.dictionary
    }
}, Xe = function(t, e, i, n, r, o) {
    var a = Ke(i, n, r, function(l, s) {
        a.terminate(),
        o(l, s);
    });
    return a.postMessage([t, e], e.consume ? [t.buffer] : []),
    function() {
        a.terminate();
    }
}, W = function(t, e) {
    return t[e] | t[e + 1] << 8
}, J = function(t, e) {
    return (t[e] | t[e + 1] << 8 | t[e + 2] << 16 | t[e + 3] << 24) >>> 0
}, Ct = function(t, e) {
    return J(t, e) + J(t, e + 4) * 4294967296
};
function Ye(t, e, i) {
    return i || (i = e,
    e = {}),
    typeof i != "function" && x(7),
    Xe(t, e, [Qe], function(n) {
        return ge(Vt(n.data[0], be(n.data[1])))
    }, 1, i)
}
function Vt(t, e) {
    return ye(t, {
        i: 2
    }, e && e.out, e && e.dictionary)
}
var Tt = typeof TextDecoder < "u" && new TextDecoder
  , Ze = 0;
try {
    Tt.decode(He, {
        stream: !0
    }),
    Ze = 1;
} catch {}
var ti = function(t) {
    for (var e = "", i = 0; ; ) {
        var n = t[i++]
          , r = (n > 127) + (n > 223) + (n > 239);
        if (i + r > t.length)
            return {
                s: e,
                r: bt(t, i - 1)
            };
        r ? r == 3 ? (n = ((n & 15) << 18 | (t[i++] & 63) << 12 | (t[i++] & 63) << 6 | t[i++] & 63) - 65536,
        e += String.fromCharCode(55296 | n >> 10, 56320 | n & 1023)) : r & 1 ? e += String.fromCharCode((n & 31) << 6 | t[i++] & 63) : e += String.fromCharCode((n & 15) << 12 | (t[i++] & 63) << 6 | t[i++] & 63) : e += String.fromCharCode(n);
    }
};
function ot(t, e) {
    if (e) {
        for (var i = "", n = 0; n < t.length; n += 16384)
            i += String.fromCharCode.apply(null, t.subarray(n, n + 16384));
        return i
    } else {
        if (Tt)
            return Tt.decode(t);
        var r = ti(t)
          , o = r.s
          , i = r.r;
        return i.length && x(8),
        o
    }
}
var ei = function(t, e) {
    return e + 30 + W(t, e + 26) + W(t, e + 28)
}
  , ii = function(t, e, i) {
    var n = W(t, e + 28)
      , r = ot(t.subarray(e + 46, e + 46 + n), !(W(t, e + 8) & 2048))
      , o = e + 46 + n
      , a = J(t, e + 20)
      , l = i && a == 4294967295 ? ni(t, o) : [a, J(t, e + 24), J(t, e + 42)]
      , s = l[0]
      , u = l[1]
      , d = l[2];
    return [W(t, e + 10), s, u, r, o + W(t, e + 30) + W(t, e + 32), d]
}
  , ni = function(t, e) {
    for (; W(t, e) != 1; e += 4 + W(t, e + 2))
        ;
    return [Ct(t, e + 12), Ct(t, e + 4), Ct(t, e + 20)]
}
  , ne = typeof queueMicrotask == "function" ? queueMicrotask : typeof setTimeout == "function" ? setTimeout : function(t) {
    t();
}
;
function ri(t, e, i) {
    i || (i = e,
    e = {}),
    typeof i != "function" && x(7);
    var n = []
      , r = function() {
        for (var v = 0; v < n.length; ++v)
            n[v]();
    }
      , o = {}
      , a = function(v, _) {
        ne(function() {
            i(v, _);
        });
    };
    ne(function() {
        a = i;
    });
    for (var l = t.length - 22; J(t, l) != 101010256; --l)
        if (!l || t.length - l > 65558)
            return a(x(13, 0, 1), null),
            r;
    var s = W(t, l + 8);
    if (s) {
        var u = s
          , d = J(t, l + 16)
          , h = d == 4294967295 || u == 65535;
        if (h) {
            var c = J(t, l - 12);
            h = J(t, c) == 101075792,
            h && (u = s = J(t, c + 32),
            d = J(t, c + 48));
        }
        for (var p = e && e.filter, m = function(v) {
            var _ = ii(t, d, h)
              , S = _[0]
              , y = _[1]
              , A = _[2]
              , P = _[3]
              , N = _[4]
              , O = _[5]
              , I = ei(t, O);
            d = N;
            var T = function(C, z) {
                C ? (r(),
                a(C, null)) : (z && (o[P] = z),
                --s || a(null, o));
            };
            if (!p || p({
                name: P,
                size: y,
                originalSize: A,
                compression: S
            }))
                if (!S)
                    T(null, bt(t, I, I + y));
                else if (S == 8) {
                    var B = t.subarray(I, I + y);
                    if (y < 32e4)
                        try {
                            T(null, Vt(B, {
                                out: new F(A)
                            }));
                        } catch (C) {
                            T(C, null);
                        }
                    else
                        n.push(Ye(B, {
                            size: A
                        }, T));
                } else
                    T(x(14, "unknown compression type " + S, 1), null);
            else
                T(null, null);
        }, f = 0; f < u; ++f)
            m(f);
    } else
        a(null, {});
    return r
}
function oi(t) {
    return (Array.isArray(t) ? t : t.issues).reduce( (e, i) => {
        if (i.path) {
            let n = i.path.map( ({key: r}) => r).join(".");
            e.nested[n] = [...e.nested[n] || [], i.message];
        } else
            e.root = [...e.root || [], i.message];
        return e
    }
    , {
        nested: {}
    })
}
var ai = class extends Error {
    issues;
    constructor(t) {
        super(t[0].message),
        this.name = "ValiError",
        this.issues = t;
    }
}
;
function si(t, e) {
    return {
        reason: t == null ? void 0 : t.reason,
        validation: e.validation,
        origin: (t == null ? void 0 : t.origin) || "value",
        message: e.message,
        input: e.input,
        abortEarly: t == null ? void 0 : t.abortEarly,
        abortPipeEarly: t == null ? void 0 : t.abortPipeEarly
    }
}
function li(t, e) {
    return {
        reason: e,
        origin: t == null ? void 0 : t.origin,
        abortEarly: t == null ? void 0 : t.abortEarly,
        abortPipeEarly: t == null ? void 0 : t.abortPipeEarly
    }
}
function Y(t, e, i, n) {
    if (!e || !e.length)
        return {
            output: t
        };
    let r, o, a = t;
    for (let l of e) {
        let s = l(a);
        if (s.issue) {
            r = r || li(i, n);
            let u = si(r, s.issue);
            if (o ? o.push(u) : o = [u],
            r.abortEarly || r.abortPipeEarly)
                break
        } else
            a = s.output;
    }
    return o ? {
        issues: o
    } : {
        output: a
    }
}
function H(t, e) {
    return !t || typeof t == "string" ? [t, e] : [void 0, t]
}
function G(t, e, i, n, r, o) {
    return {
        issues: [{
            reason: e,
            validation: i,
            origin: (t == null ? void 0 : t.origin) || "value",
            message: n,
            input: r,
            issues: o,
            abortEarly: t == null ? void 0 : t.abortEarly,
            abortPipeEarly: t == null ? void 0 : t.abortPipeEarly
        }]
    }
}
function ui(t=[]) {
    return {
        schema: "any",
        async: !1,
        _parse(e, i) {
            return Y(e, t, i, "any")
        }
    }
}
function ut(t, e, i) {
    let[n,r] = H(e, i);
    return {
        schema: "array",
        array: {
            item: t
        },
        async: !1,
        _parse(o, a) {
            if (!Array.isArray(o))
                return G(a, "type", "array", n || "Invalid type", o);
            let l, s = [];
            for (let u = 0; u < o.length; u++) {
                let d = o[u]
                  , h = t._parse(d, a);
                if (h.issues) {
                    let c = {
                        schema: "array",
                        input: o,
                        key: u,
                        value: d
                    };
                    for (let p of h.issues)
                        p.path ? p.path.unshift(c) : p.path = [c],
                        l == null || l.push(p);
                    if (l || (l = h.issues),
                    a != null && a.abortEarly)
                        break
                } else
                    s.push(h.output);
            }
            return l ? {
                issues: l
            } : Y(s, r, a, "array")
        }
    }
}
function Et(t, e) {
    let[i,n] = H(t, e);
    return {
        schema: "boolean",
        async: !1,
        _parse(r, o) {
            return typeof r != "boolean" ? G(o, "type", "boolean", i || "Invalid type", r) : Y(r, n, o, "boolean")
        }
    }
}
function re(t, e) {
    return {
        schema: "literal",
        literal: t,
        async: !1,
        _parse(i, n) {
            return i !== t ? G(n, "type", "literal", e || "Invalid type", i) : {
                output: i
            }
        }
    }
}
function hi(t, e) {
    return {
        schema: "native_enum",
        nativeEnum: t,
        async: !1,
        _parse(i, n) {
            return Object.values(t).includes(i) ? {
                output: i
            } : G(n, "type", "native_enum", e || "Invalid type", i)
        }
    }
}
function R(t, e) {
    let[i,n] = H(t, e);
    return {
        schema: "number",
        async: !1,
        _parse(r, o) {
            return typeof r != "number" ? G(o, "type", "number", i || "Invalid type", r) : Y(r, n, o, "number")
        }
    }
}
function $(t, e, i) {
    let[n,r] = H(e, i), o;
    return {
        schema: "object",
        object: t,
        async: !1,
        _parse(a, l) {
            if (!a || typeof a != "object")
                return G(l, "type", "object", n || "Invalid type", a);
            o = o || Object.entries(t);
            let s, u = {};
            for (let[d,h] of o) {
                let c = a[d]
                  , p = h._parse(c, l);
                if (p.issues) {
                    let m = {
                        schema: "object",
                        input: a,
                        key: d,
                        value: c
                    };
                    for (let f of p.issues)
                        f.path ? f.path.unshift(m) : f.path = [m],
                        s == null || s.push(f);
                    if (s || (s = p.issues),
                    l != null && l.abortEarly)
                        break
                } else
                    u[d] = p.output;
            }
            return s ? {
                issues: s
            } : Y(u, r, l, "object")
        }
    }
}
function w(t) {
    return {
        schema: "optional",
        wrapped: t,
        async: !1,
        _parse(e, i) {
            return e === void 0 ? {
                output: e
            } : t._parse(e, i)
        }
    }
}
function M(t, e) {
    let[i,n] = H(t, e);
    return {
        schema: "string",
        async: !1,
        _parse(r, o) {
            return typeof r != "string" ? G(o, "type", "string", i || "Invalid type", r) : Y(r, n, o, "string")
        }
    }
}
function di(t, e, i, n) {
    if (typeof e == "object" && !Array.isArray(e)) {
        let[a,l] = H(i, n);
        return [t, e, a, l]
    }
    let[r,o] = H(e, i);
    return [M(), t, r, o]
}
var ci = ["__proto__", "prototype", "constructor"];
function fi(t, e, i, n) {
    let[r,o,a,l] = di(t, e, i, n);
    return {
        schema: "record",
        record: {
            key: r,
            value: o
        },
        async: !1,
        _parse(s, u) {
            if (!s || typeof s != "object")
                return G(u, "type", "record", a || "Invalid type", s);
            let d, h = {};
            for (let[c,p] of Object.entries(s))
                if (!ci.includes(c)) {
                    let m, f = r._parse(c, {
                        origin: "key",
                        abortEarly: u == null ? void 0 : u.abortEarly,
                        abortPipeEarly: u == null ? void 0 : u.abortPipeEarly
                    });
                    if (f.issues) {
                        m = {
                            schema: "record",
                            input: s,
                            key: c,
                            value: p
                        };
                        for (let _ of f.issues)
                            _.path = [m],
                            d == null || d.push(_);
                        if (d || (d = f.issues),
                        u != null && u.abortEarly)
                            break
                    }
                    let v = o._parse(p, u);
                    if (v.issues) {
                        m = m || {
                            schema: "record",
                            input: s,
                            key: c,
                            value: p
                        };
                        for (let _ of v.issues)
                            _.path ? _.path.unshift(m) : _.path = [m],
                            d == null || d.push(_);
                        if (d || (d = v.issues),
                        u != null && u.abortEarly)
                            break
                    }
                    !f.issues && !v.issues && (h[f.output] = v.output);
                }
            return d ? {
                issues: d
            } : Y(h, l, u, "record")
        }
    }
}
function pi(t, e, i) {
    if (typeof t == "object" && !Array.isArray(t)) {
        let[o,a] = H(e, i);
        return [t, o, a]
    }
    let[n,r] = H(t, e);
    return [void 0, n, r]
}
function oe(t, e, i, n) {
    let[r,o,a] = pi(e, i, n);
    return {
        schema: "tuple",
        tuple: {
            items: t,
            rest: r
        },
        async: !1,
        _parse(l, s) {
            if (!Array.isArray(l) || !r && t.length !== l.length || r && t.length > l.length)
                return G(s, "type", "tuple", o || "Invalid type", l);
            let u, d = [];
            for (let h = 0; h < t.length; h++) {
                let c = l[h]
                  , p = t[h]._parse(c, s);
                if (p.issues) {
                    let m = {
                        schema: "tuple",
                        input: l,
                        key: h,
                        value: c
                    };
                    for (let f of p.issues)
                        f.path ? f.path.unshift(m) : f.path = [m],
                        u == null || u.push(f);
                    if (u || (u = p.issues),
                    s != null && s.abortEarly)
                        break
                } else
                    d[h] = p.output;
            }
            if (r)
                for (let h = t.length; h < l.length; h++) {
                    let c = l[h]
                      , p = r._parse(c, s);
                    if (p.issues) {
                        let m = {
                            schema: "tuple",
                            input: l,
                            key: h,
                            value: c
                        };
                        for (let f of p.issues)
                            f.path ? f.path.unshift(m) : f.path = [m],
                            u == null || u.push(f);
                        if (u || (u = p.issues),
                        s != null && s.abortEarly)
                            break
                    } else
                        d[h] = p.output;
                }
            return u ? {
                issues: u
            } : Y(d, a, s, "tuple")
        }
    }
}
function jt(t, e) {
    return {
        schema: "union",
        union: t,
        async: !1,
        _parse(i, n) {
            let r, o;
            for (let a of t) {
                let l = a._parse(i, n);
                if (l.issues)
                    if (r)
                        for (let s of l.issues)
                            r.push(s);
                    else
                        r = l.issues;
                else {
                    o = [l.output];
                    break
                }
            }
            return o ? {
                output: o[0]
            } : G(n, "type", "union", e || "Invalid type", i, r)
        }
    }
}
function dt(t, e, i) {
    let[n,r] = H(e, i);
    return $(t.reduce( (o, a) => ({
        ...o,
        ...a.object
    }), {}), n, r)
}
function mi(t, e, i, n) {
    let[r,o] = H(i, n);
    return $(Object.entries(t.object).reduce( (a, [l,s]) => e.includes(l) ? a : {
        ...a,
        [l]: s
    }, {}), r, o)
}
function _i(t, e, i) {
    let n = t._parse(e, i);
    return n.issues ? {
        success: !1,
        error: new ai(n.issues),
        issues: n.issues
    } : {
        success: !0,
        data: n.output,
        output: n.output
    }
}
function xt(t, e) {
    return i => i > t ? {
        issue: {
            validation: "max_value",
            message: e || "Invalid value",
            input: i
        }
    } : {
        output: i
    }
}
function Ft(t, e) {
    return i => i < t ? {
        issue: {
            validation: "min_value",
            message: e || "Invalid value",
            input: i
        }
    } : {
        output: i
    }
}
var vi = Object.create
  , $t = Object.defineProperty
  , yi = Object.getOwnPropertyDescriptor
  , we = Object.getOwnPropertyNames
  , gi = Object.getPrototypeOf
  , bi = Object.prototype.hasOwnProperty
  , wi = (t, e, i) => e in t ? $t(t, e, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: i
}) : t[e] = i
  , ct = (t, e) => function() {
    return e || (0,
    t[we(t)[0]])((e = {
        exports: {}
    }).exports, e),
    e.exports
}
  , Si = (t, e, i, n) => {
    if (e && typeof e == "object" || typeof e == "function")
        for (let r of we(e))
            !bi.call(t, r) && r !== i && $t(t, r, {
                get: () => e[r],
                enumerable: !(n = yi(e, r)) || n.enumerable
            });
    return t
}
  , Ii = (t, e, i) => (i = t != null ? vi(gi(t)) : {},
Si(e || !t || !t.__esModule ? $t(i, "default", {
    value: t,
    enumerable: !0
}) : i, t))
  , ki = (t, e, i) => (wi(t, typeof e != "symbol" ? e + "" : e, i),
i)
  , Li = ct({
    "../../node_modules/.pnpm/@rgba-image+copy@0.1.3/node_modules/@rgba-image/copy/dist/index.js"(t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }),
        t.copy = void 0;
        var e = (i, n, r=0, o=0, a=i.width - r, l=i.height - o, s=0, u=0) => {
            if (r = r | 0,
            o = o | 0,
            a = a | 0,
            l = l | 0,
            s = s | 0,
            u = u | 0,
            a <= 0 || l <= 0)
                return;
            let d = new Uint32Array(i.data.buffer)
              , h = new Uint32Array(n.data.buffer);
            for (let c = 0; c < l; c++) {
                let p = o + c;
                if (p < 0 || p >= i.height)
                    continue;
                let m = u + c;
                if (!(m < 0 || m >= n.height))
                    for (let f = 0; f < a; f++) {
                        let v = r + f;
                        if (v < 0 || v >= i.width)
                            continue;
                        let _ = s + f;
                        if (_ < 0 || _ >= n.width)
                            continue;
                        let S = p * i.width + v
                          , y = m * n.width + _;
                        h[y] = d[S];
                    }
            }
        }
        ;
        t.copy = e;
    }
})
  , Oi = ct({
    "../../node_modules/.pnpm/@rgba-image+create-image@0.1.1/node_modules/@rgba-image/create-image/dist/index.js"(t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }),
        t.CreateImageFactory = (e=[0, 0, 0, 0], i=4) => {
            if (i = Math.floor(i),
            isNaN(i) || i < 1)
                throw TypeError("channels should be a positive non-zero number");
            if (!("length"in e) || e.length < i)
                throw TypeError(`fill should be iterable with at least ${i} members`);
            e = new Uint8ClampedArray(e).slice(0, i);
            let n = e.every(r => r === 0);
            return (r, o, a) => {
                if (r === void 0 || o === void 0)
                    throw TypeError("Not enough arguments");
                if (r = Math.floor(r),
                o = Math.floor(o),
                isNaN(r) || r < 1 || isNaN(o) || o < 1)
                    throw TypeError("Index or size is negative or greater than the allowed amount");
                let l = r * o * i;
                if (a === void 0 && (a = new Uint8ClampedArray(l)),
                a instanceof Uint8ClampedArray) {
                    if (a.length !== l)
                        throw TypeError("Index or size is negative or greater than the allowed amount");
                    if (!n)
                        for (let s = 0; s < o; s++)
                            for (let u = 0; u < r; u++) {
                                let d = (s * r + u) * i;
                                for (let h = 0; h < i; h++)
                                    a[d + h] = e[h];
                            }
                    return {
                        get width() {
                            return r
                        },
                        get height() {
                            return o
                        },
                        get data() {
                            return a
                        }
                    }
                }
                throw TypeError("Expected data to be Uint8ClampedArray or undefined")
            }
        }
        ,
        t.createImage = t.CreateImageFactory();
    }
})
  , Mi = ct({
    "../../node_modules/.pnpm/@rgba-image+lanczos@0.1.1/node_modules/@rgba-image/lanczos/dist/filters.js"(t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }),
        t.filters = void 0;
        var e = 14
          , i = (o, a) => {
            if (o <= -a || o >= a || o == 0)
                return 0;
            let l = o * Math.PI;
            return Math.sin(l) / l * Math.sin(l / a) / (l / a)
        }
          , n = o => Math.round(o * ((1 << e) - 1))
          , r = (o, a, l, s, u) => {
            let d = u ? 2 : 3
              , h = 1 / l
              , c = Math.min(1, l)
              , p = d / c
              , m = Math.floor((p + 1) * 2)
              , f = new Int16Array((m + 2) * a)
              , v = 0;
            for (let _ = 0; _ < a; _++) {
                let S = (_ + .5) * h + s
                  , y = Math.max(0, Math.floor(S - p))
                  , A = Math.min(o - 1, Math.ceil(S + p))
                  , P = A - y + 1
                  , N = new Float32Array(P)
                  , O = new Int16Array(P)
                  , I = 0
                  , T = 0;
                for (let E = y; E <= A; E++) {
                    let Q = i((E + .5 - S) * c, d);
                    I += Q,
                    N[T] = Q,
                    T++;
                }
                let B = 0;
                for (let E = 0; E < N.length; E++) {
                    let Q = N[E] / I;
                    B += Q,
                    O[E] = n(Q);
                }
                O[a >> 1] += n(1 - B);
                let C = 0;
                for (; C < O.length && O[C] === 0; )
                    C++;
                let z = O.length - 1;
                for (; z > 0 && O[z] === 0; )
                    z--;
                let j = y + C
                  , U = z - C + 1;
                f[v++] = j,
                f[v++] = U,
                f.set(O.subarray(C, z + 1), v),
                v += U;
            }
            return f
        }
        ;
        t.filters = r;
    }
})
  , Ai = ct({
    "../../node_modules/.pnpm/@rgba-image+lanczos@0.1.1/node_modules/@rgba-image/lanczos/dist/convolve.js"(t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }),
        t.convolve = void 0;
        var e = 14
          , i = (n, r, o, a, l, s) => {
            let u = 0
              , d = 0;
            for (let h = 0; h < a; h++) {
                let c = 0;
                for (let p = 0; p < l; p++) {
                    let m = s[c++]
                      , f = u + m * 4 | 0
                      , v = 0
                      , _ = 0
                      , S = 0
                      , y = 0;
                    for (let A = s[c++]; A > 0; A--) {
                        let P = s[c++];
                        v = v + P * n[f] | 0,
                        _ = _ + P * n[f + 1] | 0,
                        S = S + P * n[f + 2] | 0,
                        y = y + P * n[f + 3] | 0,
                        f = f + 4 | 0;
                    }
                    r[d] = v + 8192 >> e,
                    r[d + 1] = _ + 8192 >> e,
                    r[d + 2] = S + 8192 >> e,
                    r[d + 3] = y + 8192 >> e,
                    d = d + a * 4 | 0;
                }
                d = (h + 1) * 4 | 0,
                u = (h + 1) * o * 4 | 0;
            }
        }
        ;
        t.convolve = i;
    }
})
  , Pi = ct({
    "../../node_modules/.pnpm/@rgba-image+lanczos@0.1.1/node_modules/@rgba-image/lanczos/dist/index.js"(t) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }),
        t.lanczos2 = t.lanczos = void 0;
        var e = Li()
          , i = Oi()
          , n = Mi()
          , r = Ai()
          , o = (s, u, d=!1) => {
            let h = u.width / s.width
              , c = u.height / s.height
              , p = n.filters(s.width, u.width, h, 0, d)
              , m = n.filters(s.height, u.height, c, 0, d)
              , f = new Uint8ClampedArray(u.width * s.height * 4);
            r.convolve(s.data, f, s.width, s.height, u.width, p),
            r.convolve(f, u.data, s.height, u.width, u.height, m);
        }
          , a = (s, u, d=0, h=0, c=s.width - d, p=s.height - h, m=0, f=0, v=u.width - m, _=u.height - f) => {
            if (d = d | 0,
            h = h | 0,
            c = c | 0,
            p = p | 0,
            m = m | 0,
            f = f | 0,
            v = v | 0,
            _ = _ | 0,
            c <= 0 || p <= 0 || v <= 0 || _ <= 0)
                return;
            if (d === 0 && h === 0 && c === s.width && p === s.height && m === 0 && f === 0 && v === u.width && _ === u.height) {
                o(s, u);
                return
            }
            let S = i.createImage(c, p)
              , y = i.createImage(v, _);
            e.copy(s, S, d, h),
            o(S, y),
            e.copy(y, u, 0, 0, y.width, y.height, m, f);
        }
        ;
        t.lanczos = a;
        var l = (s, u, d=0, h=0, c=s.width - d, p=s.height - h, m=0, f=0, v=u.width - m, _=u.height - f) => {
            if (d = d | 0,
            h = h | 0,
            c = c | 0,
            p = p | 0,
            m = m | 0,
            f = f | 0,
            v = v | 0,
            _ = _ | 0,
            c <= 0 || p <= 0 || v <= 0 || _ <= 0)
                return;
            if (d === 0 && h === 0 && c === s.width && p === s.height && m === 0 && f === 0 && v === u.width && _ === u.height) {
                o(s, u, !0);
                return
            }
            let S = i.createImage(c, p)
              , y = i.createImage(v, _);
            e.copy(s, S, d, h),
            o(S, y, !0),
            e.copy(y, u, 0, 0, y.width, y.height, m, f);
        }
        ;
        t.lanczos2 = l;
    }
})
  , Se = (t => (t.Bounce = "bounce",
t.Normal = "normal",
t))(Se || {})
  , Ci = hi(Se)
  , Ie = $({
    autoplay: w(Et()),
    defaultTheme: w(M()),
    direction: w(jt([re(1), re(-1)])),
    hover: w(Et()),
    id: M(),
    intermission: w(R()),
    loop: w(jt([Et(), R()])),
    playMode: w(Ci),
    speed: w(R()),
    themeColor: w(M())
})
  , Ei = $({
    animations: ut(M()),
    id: M()
})
  , Ti = $({
    activeAnimationId: w(M()),
    animations: ut(Ie),
    author: w(M()),
    custom: w(fi(M(), ui())),
    description: w(M()),
    generator: w(M()),
    keywords: w(M()),
    revision: w(R()),
    themes: w(ut(Ei)),
    states: w(ut(M())),
    version: w(M())
})
  , qt = mi(Ie, ["id"])
  , tt = $({
    state: M()
})
  , ji = tt
  , xi = dt([tt, $({
    ms: R()
})])
  , Fi = dt([tt, $({
    count: R()
})])
  , Ni = tt
  , zi = tt
  , Di = tt
  , Ui = dt([tt, $({
    threshold: w(ut(R([Ft(0), xt(1)])))
})])
  , Vi = $({
    onAfter: w(xi),
    onClick: w(ji),
    onComplete: w(Di),
    onEnter: w(Fi),
    onMouseEnter: w(Ni),
    onMouseLeave: w(zi),
    onShow: w(Ui)
})
  , $i = dt([qt, $({
    playOnScroll: w(oe([R([Ft(0), xt(1)]), R([Ft(0), xt(1)])])),
    segments: w(jt([oe([R(), R()]), M()]))
})]);
dt([Vi, $({
    animationId: w(M()),
    playbackSettings: $i
})]);
var qi = {
    jpeg: "image/jpeg",
    png: "image/png",
    gif: "image/gif",
    bmp: "image/bmp",
    svg: "image/svg+xml",
    webp: "image/webp",
    mpeg: "audio/mpeg",
    mp3: "audio/mp3"
}
  , ae = {
    jpeg: [255, 216, 255],
    png: [137, 80, 78, 71, 13, 10, 26, 10],
    gif: [71, 73, 70],
    bmp: [66, 77],
    webp: [82, 73, 70, 70, 87, 69, 66, 80],
    svg: [60, 63, 120],
    mp3: [73, 68, 51, 3, 0, 0, 0, 0],
    mpeg: [73, 68, 51, 3, 0, 0, 0, 0]
}
  , Bi = t => {
    let e = null
      , i = [];
    if (!t)
        return null;
    let n = t.substring(t.indexOf(",") + 1);
    typeof window > "u" ? e = Buffer.from(n, "base64").toString("binary") : e = atob(n);
    let r = new Uint8Array(e.length);
    for (let o = 0; o < e.length; o += 1)
        r[o] = e.charCodeAt(o);
    i = Array.from(r.subarray(0, 8));
    for (let o in ae) {
        let a = ae[o];
        if (a && i.every( (l, s) => l === a[s]))
            return qi[o]
    }
    return null
}
  , Bt = class extends Error {
    constructor(t, e) {
        super(t),
        ki(this, "code"),
        this.name = "[dotlottie-js]",
        this.code = e;
    }
}
;
function ke(t) {
    let e;
    if (typeof window > "u")
        e = Buffer.from(t).toString("base64");
    else {
        let i = Array.prototype.map.call(t, n => String.fromCharCode(n)).join("");
        e = window.btoa(i);
    }
    return `data:${Bi(e)};base64,${e}`
}
function se(t) {
    return "w"in t && "h"in t && !("xt"in t) && "p"in t
}
function Nt(t) {
    return !("h"in t) && !("w"in t) && "p"in t && "e"in t && "u"in t && "id"in t
}
async function ft(t, e= () => !0) {
    if (!(t instanceof Uint8Array))
        throw new Bt("DotLottie not found","INVALID_DOTLOTTIE");
    return await new Promise( (i, n) => {
        ri(t, {
            filter: e
        }, (r, o) => {
            r && n(r),
            i(o);
        }
        );
    }
    )
}
async function Jt(t, e, i) {
    if (!(t instanceof Uint8Array))
        throw new Bt("DotLottie not found","INVALID_DOTLOTTIE");
    return (await ft(t, n => n.name === e && (!i || i(n))))[e]
}
async function wt(t) {
    let e = "manifest.json"
      , i = (await ft(t, n => n.name === e))[e];
    if (!(typeof i > "u"))
        return JSON.parse(ot(i, !1))
}
async function Ji(t) {
    if (!(t instanceof Uint8Array))
        return {
            success: !1,
            error: "DotLottie not found"
        };
    let e = await wt(t);
    if (typeof e > "u")
        return {
            success: !1,
            error: "Invalid .lottie file, manifest.json is missing"
        };
    let i = _i(Ti, e);
    return i.success ? {
        success: !0
    } : {
        success: !1,
        error: `Invalid .lottie file, manifest.json structure is invalid, ${JSON.stringify(oi(i.error).nested, null, 2)}`
    }
}
async function Rt(t) {
    let e = new Uint8Array(t)
      , i = await Ji(e);
    if (i.error)
        throw new Bt(i.error,"INVALID_DOTLOTTIE");
    return e
}
async function Ri(t, e) {
    let i = await ft(t, r => {
        let o = r.name.replace("audio/", "");
        return r.name.startsWith("audio/") && (!e || e({
            ...r,
            name: o
        }))
    }
    )
      , n = {};
    for (let r in i) {
        let o = i[r];
        if (o instanceof Uint8Array) {
            let a = r.replace("audio/", "");
            n[a] = ke(o);
        }
    }
    return n
}
async function Hi(t, e) {
    var i;
    let n = new Map;
    for (let[o,a] of Object.entries(e))
        for (let l of a.assets || [])
            if (Nt(l)) {
                let s = l.p;
                n.has(s) || n.set(s, new Set),
                (i = n.get(s)) == null || i.add(o);
            }
    let r = await Ri(t, o => n.has(o.name));
    for (let[o,a] of n) {
        let l = r[o];
        if (l)
            for (let s of a) {
                let u = e[s];
                for (let d of (u == null ? void 0 : u.assets) || [])
                    Nt(d) && d.p === o && (d.p = l,
                    d.u = "",
                    d.e = 1);
            }
    }
}
async function Wi(t, e) {
    let i = await ft(t, r => {
        let o = r.name.replace("images/", "");
        return r.name.startsWith("images/") && (!e || e({
            ...r,
            name: o
        }))
    }
    )
      , n = {};
    for (let r in i) {
        let o = i[r];
        if (o instanceof Uint8Array) {
            let a = r.replace("images/", "");
            n[a] = ke(o);
        }
    }
    return n
}
async function Gi(t, e) {
    var i;
    let n = new Map;
    for (let[o,a] of Object.entries(e))
        for (let l of a.assets || [])
            if (se(l)) {
                let s = l.p;
                n.has(s) || n.set(s, new Set),
                (i = n.get(s)) == null || i.add(o);
            }
    let r = await Wi(t, o => n.has(o.name));
    for (let[o,a] of n) {
        let l = r[o];
        if (l)
            for (let s of a) {
                let u = e[s];
                for (let d of (u == null ? void 0 : u.assets) || [])
                    se(d) && d.p === o && (d.p = l,
                    d.u = "",
                    d.e = 1);
            }
    }
}
async function Le(t, e, {inlineAssets: i}={}, n) {
    let r = `animations/${e}.json`
      , o = await Jt(t, r, n);
    if (typeof o > "u")
        return;
    let a = JSON.parse(ot(o, !1));
    if (!i)
        return a;
    let l = {
        [e]: a
    };
    return await Gi(t, l),
    await Hi(t, l),
    a
}
async function Oe(t, e, i) {
    let n = `themes/${e}.json`
      , r = await Jt(t, n, i);
    if (!(typeof r > "u"))
        return JSON.parse(ot(r, !1))
}
async function Me(t, e) {
    let i = {}
      , n = await ft(t, r => {
        let o = r.name.replace("states/", "").replace(".json", "");
        return r.name.startsWith("states/") && (!e || e({
            ...r,
            name: o
        }))
    }
    );
    for (let r in n) {
        let o = n[r];
        if (o instanceof Uint8Array) {
            let a = r.replace("states/", "").replace(".json", "");
            i[a] = ot(o, !1);
        }
    }
    return i
}
async function Ae(t, e, i) {
    let n = `states/${e}.json`
      , r = await Jt(t, n, i);
    return typeof r > "u" ? void 0 : JSON.parse(ot(r, !1))
}
Ii(Pi());
function g(t, e="dotLottie-common") {
    return new Error(`[${e}]: ${t}`)
}
function et(t, e="dotLottie-common", ...i) {
    console.error(`[${e}]:`, t, ...i);
}
function k(t, e="dotLottie-common", ...i) {
    console.warn(`[${e}]:`, t, ...i);
}
function Pe(t="") {
    let e = t.trim()
      , i = e.lastIndexOf("/")
      , n = e.substring(i + 1)
      , r = n.indexOf(".");
    return r !== -1 ? n.substring(0, r) : n
}
function at(t) {
    return ["v", "ip", "op", "layers", "fr", "w", "h"].every(e => Object.prototype.hasOwnProperty.call(t, e))
}
function Ce(t) {
    let e = t.assets;
    return e ? e.some(i => Nt(i)) : !1
}
function Ee(t) {
    try {
        let e = JSON.parse(t);
        return at(e)
    } catch {
        return !1
    }
}
function rn(t, e) {
    let i = Object.keys(t).find(n => t[n] === e);
    if (i === void 0)
        throw new Error("Value not found in the object.");
    return i
}
function St(t) {
    return JSON.parse(JSON.stringify(t))
}
var Te = class {
    _dotLottie;
    _animationsMap = new Map;
    _themeMap = new Map;
    _stateMachinesMap = new Map;
    _manifest;
    get dotLottie() {
        return this._dotLottie
    }
    get animationsMap() {
        return this._animationsMap
    }
    get themeMap() {
        return this._themeMap
    }
    get stateMachinesMap() {
        return this._stateMachinesMap
    }
    get manifest() {
        return this._manifest
    }
    async loadFromUrl(t) {
        let e = await fetch(t, {
            method: "GET",
            mode: "cors"
        });
        if (!e.ok)
            throw new Error(`Failed to load dotLottie from ${t} with status ${e.status}`);
        let i = e.headers.get("content-type");
        if (i != null && i.includes("application/json")) {
            let n = await e.json();
            if (!at(n))
                throw new Error(`Invalid lottie JSON at ${t}`);
            let r = Pe(t);
            this._animationsMap.set(r, n);
            let o = {
                activeAnimationId: r,
                animations: [{
                    id: r
                }]
            };
            this._manifest = o;
        } else {
            this._dotLottie = await Rt(await e.arrayBuffer());
            let n = await wt(this._dotLottie);
            if (!n)
                throw new Error("Manifest not found");
            this._manifest = n;
        }
    }
    loadFromLottieJSON(t) {
        if (!at(t))
            throw new Error("Invalid lottie JSON");
        let e = "my-animation";
        this._animationsMap.set(e, t);
        let i = {
            activeAnimationId: e,
            animations: [{
                id: e
            }]
        };
        this._manifest = i;
    }
    async loadFromArrayBuffer(t) {
        this._dotLottie = await Rt(t);
        let e = await wt(this._dotLottie);
        if (!e)
            throw new Error("Manifest not found");
        this._manifest = e;
    }
    async getAnimation(t) {
        if (this._animationsMap.get(t))
            return this._animationsMap.get(t);
        if (!this._dotLottie)
            return;
        let e = await Le(this._dotLottie, t, {
            inlineAssets: !0
        });
        return e && this._animationsMap.set(t, e),
        e
    }
    async getTheme(t) {
        if (this._themeMap.get(t))
            return this._themeMap.get(t);
        if (!this._dotLottie)
            return;
        let e = await Oe(this._dotLottie, t);
        return e && this._themeMap.set(t, e),
        e
    }
    async getStateMachines() {
        if (!this._dotLottie)
            return;
        let t = await Me(this._dotLottie);
        for (let e in t)
            if (e) {
                let i = t[e];
                if (i) {
                    let n = JSON.parse(i);
                    if (n) {
                        let r = n.descriptor.id;
                        this._stateMachinesMap.get(r) || this._stateMachinesMap.set(r, n);
                    }
                }
            }
        return Array.from(this._stateMachinesMap.values())
    }
    async getStateMachine(t) {
        if (this._stateMachinesMap.get(t))
            return this._stateMachinesMap.get(t);
        if (!this._dotLottie)
            return;
        let e = await Ae(this._dotLottie, t);
        return e && this._stateMachinesMap.set(e.descriptor.id, e),
        e
    }
}
;
function kt() {
    throw new Error("Cycle detected")
}
function Wt() {
    if (st > 1)
        st--;
    else {
        for (var t, e = !1; pt !== void 0; ) {
            var i = pt;
            for (pt = void 0,
            Ht++; i !== void 0; ) {
                var n = i.o;
                if (i.o = void 0,
                i.f &= -3,
                !(8 & i.f) && xe(i))
                    try {
                        i.c();
                    } catch (r) {
                        e || (t = r,
                        e = !0);
                    }
                i = n;
            }
        }
        if (Ht = 0,
        st--,
        e)
            throw t
    }
}
var L = void 0
  , pt = void 0
  , st = 0
  , Ht = 0
  , It = 0;
function je(t) {
    if (L !== void 0) {
        var e = t.n;
        if (e === void 0 || e.t !== L)
            return e = {
                i: 0,
                S: t,
                p: L.s,
                n: void 0,
                t: L,
                e: void 0,
                x: void 0,
                r: e
            },
            L.s !== void 0 && (L.s.n = e),
            L.s = e,
            t.n = e,
            32 & L.f && t.S(e),
            e;
        if (e.i === -1)
            return e.i = 0,
            e.n !== void 0 && (e.n.p = e.p,
            e.p !== void 0 && (e.p.n = e.n),
            e.p = L.s,
            e.n = void 0,
            L.s.n = e,
            L.s = e),
            e
    }
}
function D(t) {
    this.v = t,
    this.i = 0,
    this.n = void 0,
    this.t = void 0;
}
D.prototype.h = function() {
    return !0
}
;
D.prototype.S = function(t) {
    this.t !== t && t.e === void 0 && (t.x = this.t,
    this.t !== void 0 && (this.t.e = t),
    this.t = t);
}
;
D.prototype.U = function(t) {
    if (this.t !== void 0) {
        var e = t.e
          , i = t.x;
        e !== void 0 && (e.x = i,
        t.e = void 0),
        i !== void 0 && (i.e = e,
        t.x = void 0),
        t === this.t && (this.t = i);
    }
}
;
D.prototype.subscribe = function(t) {
    var e = this;
    return Xi(function() {
        var i = e.value
          , n = 32 & this.f;
        this.f &= -33;
        try {
            t(i);
        } finally {
            this.f |= n;
        }
    })
}
;
D.prototype.valueOf = function() {
    return this.value
}
;
D.prototype.toString = function() {
    return this.value + ""
}
;
D.prototype.toJSON = function() {
    return this.value
}
;
D.prototype.peek = function() {
    return this.v
}
;
Object.defineProperty(D.prototype, "value", {
    get: function() {
        var t = je(this);
        return t !== void 0 && (t.i = this.i),
        this.v
    },
    set: function(t) {
        if (L instanceof it && function() {
            throw new Error("Computed cannot have side-effects")
        }(),
        t !== this.v) {
            Ht > 100 && kt(),
            this.v = t,
            this.i++,
            It++,
            st++;
            try {
                for (var e = this.t; e !== void 0; e = e.x)
                    e.t.N();
            } finally {
                Wt();
            }
        }
    }
});
function Ki(t) {
    return new D(t)
}
function xe(t) {
    for (var e = t.s; e !== void 0; e = e.n)
        if (e.S.i !== e.i || !e.S.h() || e.S.i !== e.i)
            return !0;
    return !1
}
function Fe(t) {
    for (var e = t.s; e !== void 0; e = e.n) {
        var i = e.S.n;
        if (i !== void 0 && (e.r = i),
        e.S.n = e,
        e.i = -1,
        e.n === void 0) {
            t.s = e;
            break
        }
    }
}
function Ne(t) {
    for (var e = t.s, i = void 0; e !== void 0; ) {
        var n = e.p;
        e.i === -1 ? (e.S.U(e),
        n !== void 0 && (n.n = e.n),
        e.n !== void 0 && (e.n.p = n)) : i = e,
        e.S.n = e.r,
        e.r !== void 0 && (e.r = void 0),
        e = n;
    }
    t.s = i;
}
function it(t) {
    D.call(this, void 0),
    this.x = t,
    this.s = void 0,
    this.g = It - 1,
    this.f = 4;
}
(it.prototype = new D).h = function() {
    if (this.f &= -3,
    1 & this.f)
        return !1;
    if ((36 & this.f) == 32 || (this.f &= -5,
    this.g === It))
        return !0;
    if (this.g = It,
    this.f |= 1,
    this.i > 0 && !xe(this))
        return this.f &= -2,
        !0;
    var t = L;
    try {
        Fe(this),
        L = this;
        var e = this.x();
        (16 & this.f || this.v !== e || this.i === 0) && (this.v = e,
        this.f &= -17,
        this.i++);
    } catch (i) {
        this.v = i,
        this.f |= 16,
        this.i++;
    }
    return L = t,
    Ne(this),
    this.f &= -2,
    !0
}
;
it.prototype.S = function(t) {
    if (this.t === void 0) {
        this.f |= 36;
        for (var e = this.s; e !== void 0; e = e.n)
            e.S.S(e);
    }
    D.prototype.S.call(this, t);
}
;
it.prototype.U = function(t) {
    if (this.t !== void 0 && (D.prototype.U.call(this, t),
    this.t === void 0)) {
        this.f &= -33;
        for (var e = this.s; e !== void 0; e = e.n)
            e.S.U(e);
    }
}
;
it.prototype.N = function() {
    if (!(2 & this.f)) {
        this.f |= 6;
        for (var t = this.t; t !== void 0; t = t.x)
            t.t.N();
    }
}
;
it.prototype.peek = function() {
    if (this.h() || kt(),
    16 & this.f)
        throw this.v;
    return this.v
}
;
Object.defineProperty(it.prototype, "value", {
    get: function() {
        1 & this.f && kt();
        var t = je(this);
        if (this.h(),
        t !== void 0 && (t.i = this.i),
        16 & this.f)
            throw this.v;
        return this.v
    }
});
function ze(t) {
    var e = t.u;
    if (t.u = void 0,
    typeof e == "function") {
        st++;
        var i = L;
        L = void 0;
        try {
            e();
        } catch (n) {
            throw t.f &= -2,
            t.f |= 8,
            Gt(t),
            n
        } finally {
            L = i,
            Wt();
        }
    }
}
function Gt(t) {
    for (var e = t.s; e !== void 0; e = e.n)
        e.S.U(e);
    t.x = void 0,
    t.s = void 0,
    ze(t);
}
function Qi(t) {
    if (L !== this)
        throw new Error("Out-of-order effect");
    Ne(this),
    L = t,
    this.f &= -2,
    8 & this.f && Gt(this),
    Wt();
}
function mt(t) {
    this.x = t,
    this.u = void 0,
    this.s = void 0,
    this.o = void 0,
    this.f = 32;
}
mt.prototype.c = function() {
    var t = this.S();
    try {
        if (8 & this.f || this.x === void 0)
            return;
        var e = this.x();
        typeof e == "function" && (this.u = e);
    } finally {
        t();
    }
}
;
mt.prototype.S = function() {
    1 & this.f && kt(),
    this.f |= 1,
    this.f &= -9,
    ze(this),
    Fe(this),
    st++;
    var t = L;
    return L = this,
    Qi.bind(this, t)
}
;
mt.prototype.N = function() {
    2 & this.f || (this.f |= 2,
    this.o = pt,
    pt = this);
}
;
mt.prototype.d = function() {
    this.f |= 8,
    1 & this.f || Gt(this);
}
;
function Xi(t) {
    var e = new mt(t);
    try {
        e.c();
    } catch (i) {
        throw e.d(),
        i
    }
    return e.d.bind(e)
}
var De = class {
    _state;
    _prevState;
    constructor(t) {
        this._prevState = t,
        this._state = Ki(t);
    }
    setState(t) {
        this._prevState = this._state.value,
        this._state.value = t;
    }
    subscribe(t) {
        return this._state.subscribe(e => t(e, this._prevState))
    }
}
;
async function Ue(t, e) {
    let[{DotLottieStateMachineManager: i}] = await Promise.all([import('./dotlottie-state-machine-manager-2E7RUGJG-NTQ25VSR.mjs')]);
    if (!t.length)
        throw g("No state machines available inside this .lottie!");
    return new i(t,e)
}
var Yi = {
    name: "@dotlottie/common",
    version: "0.7.11",
    type: "module",
    description: "",
    author: "Afsal <afsal@lottiefiles.com>, Sam Osborne <sam@lottiefiles.com>",
    license: "MIT",
    engines: {
        node: ">18.0.0"
    },
    module: "dist/index.js",
    main: "dist/index.js",
    types: "dist/index.d.ts",
    files: ["dist"],
    keywords: [],
    scripts: {
        build: "tsup",
        dev: "tsup --watch",
        lint: "eslint .",
        "type-check": "tsc --noEmit"
    },
    dependencies: {
        "@dotlottie/dotlottie-js": "^0.7.0",
        "@preact/signals-core": "^1.2.3",
        howler: "^2.2.3",
        "lottie-web": "^5.12.2",
        xstate: "^4.38.1"
    },
    devDependencies: {
        "@lottiefiles/lottie-types": "^1.2.0",
        "@types/howler": "^2.2.8",
        tsup: "^7.2.0",
        typescript: "^4.7.4"
    },
    publishConfig: {
        access: "public"
    }
}
  , Zi = (t => (t.Complete = "complete",
t.DataFail = "data_fail",
t.DataReady = "data_ready",
t.Error = "error",
t.Frame = "frame",
t.Freeze = "freeze",
t.LoopComplete = "loopComplete",
t.Pause = "pause",
t.Play = "play",
t.Ready = "ready",
t.Stop = "stop",
t.VisibilityChange = "visibilityChange",
t))(Zi || {})
  , tn = (t => (t.Completed = "completed",
t.Error = "error",
t.Fetching = "fetching",
t.Frozen = "frozen",
t.Initial = "initial",
t.Loading = "loading",
t.Paused = "paused",
t.Playing = "playing",
t.Ready = "ready",
t.Stopped = "stopped",
t))(tn || {})
  , en = (t => (t.Bounce = "bounce",
t.Normal = "normal",
t))(en || {})
  , q = {
    autoplay: !1,
    direction: 1,
    hover: !1,
    intermission: 0,
    loop: !1,
    playMode: "normal",
    speed: 1,
    defaultTheme: ""
}
  , nn = {
    activeStateId: "",
    autoplay: !1,
    currentState: "initial",
    frame: 0,
    seeker: 0,
    direction: 1,
    hover: !1,
    loop: !1,
    playMode: "normal",
    speed: 1,
    background: "transparent",
    intermission: 0,
    currentAnimationId: void 0,
    visibilityPercentage: 0
}
  , gn = class {
    _lottie;
    _src;
    _animationConfig;
    _prevUserPlaybackOptions = {};
    _userPlaybackOptions;
    _hover = !1;
    _loop = !1;
    _counter = 0;
    _intermission = 0;
    _counterInterval = null;
    _container = null;
    _name;
    _mode = "normal";
    _background = "transparent";
    _animation;
    _defaultTheme;
    _activeAnimationId;
    _currentAnimationId;
    _testId;
    _listeners = new Map;
    _currentState = "initial";
    _stateBeforeFreeze = "initial";
    state = new De(nn);
    _light = !1;
    _worker = !1;
    _dotLottieLoader = new Te;
    _activeStateId;
    _inInteractiveMode = !1;
    _scrollTicking = !1;
    _scrollCallback = void 0;
    _onShowIntersectionObserver = void 0;
    _visibilityPercentage = 0;
    _audios = [];
    _stateMachineManager;
    constructor(t, e, i) {
        typeof t == "string" ? this._src = t : this._src = St(t),
        i != null && i.testId && (this._testId = i.testId),
        this._defaultTheme = (i == null ? void 0 : i.defaultTheme) || "",
        this._userPlaybackOptions = this._validatePlaybackOptions(i || {}),
        typeof (i == null ? void 0 : i.activeAnimationId) == "string" && (this._activeAnimationId = i.activeAnimationId),
        this._container = e || null,
        typeof (i == null ? void 0 : i.background) == "string" && this.setBackground(i.background),
        typeof (i == null ? void 0 : i.activeStateId) < "u" && (this._activeStateId = i.activeStateId);
        let {rendererSettings: n, ...r} = i || {};
        this._animationConfig = {
            loop: !1,
            autoplay: !1,
            renderer: "svg",
            rendererSettings: {
                clearCanvas: !0,
                progressiveLoad: !0,
                hideOnTransparent: !0,
                filterSize: {
                    width: "200%",
                    height: "200%",
                    x: "-50%",
                    y: "-50%"
                },
                ...n
            },
            ...r
        },
        i != null && i.light && (this._light = i.light),
        i != null && i.worker && (this._worker = i.worker),
        this._listenToHover(),
        this._listenToVisibilityChange();
    }
    _listenToHover() {
        var t, e, i, n;
        let r = () => {
            this._hover && this.currentState !== "playing" && this.play();
        }
          , o = () => {
            this._hover && this.currentState === "playing" && this.stop();
        }
        ;
        (t = this._container) == null || t.removeEventListener("mouseenter", r),
        (e = this._container) == null || e.removeEventListener("mouseleave", o),
        (i = this._container) == null || i.addEventListener("mouseleave", o),
        (n = this._container) == null || n.addEventListener("mouseenter", r);
    }
    _onVisibilityChange() {
        !this._lottie || typeof document > "u" || (document.hidden && this.currentState === "playing" ? this.freeze() : this.currentState === "frozen" && this.unfreeze());
    }
    _listenToVisibilityChange() {
        typeof document < "u" && typeof document.hidden < "u" && document.addEventListener("visibilitychange", () => this._onVisibilityChange());
    }
    _getOption(t) {
        var e;
        if (typeof this._userPlaybackOptions[t] < "u")
            return this._userPlaybackOptions[t];
        let i = (e = this._dotLottieLoader.manifest) == null ? void 0 : e.animations.find(n => n.id === this._currentAnimationId);
        return i && typeof i[t] < "u" ? i[t] : q[t]
    }
    _getPlaybackOptions() {
        let t = {};
        for (let e in q)
            typeof q[e] < "u" && (t[e] = this._getOption(e));
        return t
    }
    _setPlayerState(t) {
        var e, i, n;
        let r = t(this._getPlaybackOptions());
        try {
            qt._parse(r);
        } catch {
            k(`Invalid PlaybackOptions, ${JSON.stringify(r, null, 2)}`);
            return
        }
        typeof r.defaultTheme < "u" && (this._defaultTheme = r.defaultTheme),
        typeof r.playMode < "u" && (this._mode = r.playMode),
        typeof r.intermission < "u" && (this._intermission = r.intermission),
        typeof r.hover < "u" && (this._hover = r.hover),
        typeof r.loop < "u" && (this.clearCountTimer(),
        this._loop = r.loop,
        this._counter = 0,
        (e = this._lottie) == null || e.setLoop(typeof r.loop == "number" ? !0 : r.loop)),
        typeof r.speed < "u" && ((i = this._lottie) == null || i.setSpeed(r.speed)),
        typeof r.autoplay < "u" && this._lottie && (this._lottie.autoplay = r.autoplay),
        typeof r.direction < "u" && ((n = this._lottie) == null || n.setDirection(r.direction));
    }
    _getOptionsFromAnimation(t) {
        let {id: e, ...i} = t;
        return {
            ...q,
            ...i
        }
    }
    _updateTestData() {
        !this._testId || !this._lottie || (window.dotLottiePlayer || (window.dotLottiePlayer = {
            [this._testId]: {}
        }),
        window.dotLottiePlayer[this._testId] = {
            direction: this._lottie.playDirection,
            currentState: this._currentState,
            loop: this.loop,
            mode: this._mode,
            speed: this._lottie.playSpeed
        });
    }
    setContainer(t) {
        t !== this._container && (this._container = t,
        this.setBackground(this._background),
        this._listenToHover());
    }
    get currentState() {
        return this._currentState
    }
    clearCountTimer() {
        this._counterInterval && clearInterval(this._counterInterval);
    }
    setCurrentState(t) {
        this._currentState = t,
        this._notify(),
        this._updateTestData();
    }
    static isPathJSON(t) {
        var e;
        return ((e = t.split(".").pop()) == null ? void 0 : e.toLowerCase()) === "json"
    }
    get src() {
        return this._src
    }
    updateSrc(t) {
        this._src !== t && (typeof t == "string" ? this._src = t : this._src = St(t),
        this._activeAnimationId = void 0,
        this._currentAnimationId = void 0,
        this.load());
    }
    get intermission() {
        return this._intermission
    }
    get hover() {
        return this._hover
    }
    setHover(t) {
        typeof t == "boolean" && (this._hover = t,
        this._userPlaybackOptions.hover = t,
        this._notify());
    }
    setIntermission(t) {
        this._intermission = t,
        this._userPlaybackOptions.intermission = t,
        this._notify();
    }
    get mode() {
        return this._mode
    }
    get animations() {
        return this._dotLottieLoader.animationsMap
    }
    get themes() {
        return this._dotLottieLoader.themeMap
    }
    setMode(t) {
        typeof t == "string" && (this._mode = t,
        this._userPlaybackOptions.playMode = t,
        this._setPlayerState( () => ({
            playMode: t
        })),
        this._notify(),
        this._updateTestData());
    }
    get container() {
        if (this._container)
            return this._container
    }
    goToAndPlay(t, e, i) {
        if (!this._lottie || ["loading"].includes(this._currentState)) {
            k("goToAndPlay() Can't use whilst loading.");
            return
        }
        this._lottie.goToAndPlay(t, e, i),
        this.setCurrentState("playing");
    }
    goToAndStop(t, e, i) {
        if (!this._lottie || ["loading"].includes(this._currentState)) {
            k("goToAndStop() Can't use whilst loading.");
            return
        }
        this._lottie.goToAndStop(t, e, i),
        this.setCurrentState("stopped");
    }
    seek(t) {
        if (!this._lottie || ["loading"].includes(this._currentState)) {
            k("seek() Can't use whilst loading.");
            return
        }
        let e = t;
        typeof e == "number" && (e = Math.round(e));
        let i = /^(\d+)(%?)$/u.exec(e.toString());
        if (!i)
            return;
        let n = i[2] === "%" ? this.totalFrames * Number(i[1]) / 100 : i[1];
        n !== void 0 && (this._lottie.goToAndPlay(n, !0),
        this.currentState === "playing" ? this.play() : this.currentState === "frozen" ? this.freeze() : this.pause());
    }
    _areNumbersInRange(t, e) {
        return t >= 0 && t <= 1 && e >= 0 && e <= 1
    }
    _updatePosition(t, e, i) {
        let[n,r] = t != null ? t : [0, this.totalFrames - 1]
          , [o,a] = e != null ? e : [0, 1];
        if (!this._areNumbersInRange(o, a)) {
            et("threshold values must be between 0 and 1");
            return
        }
        if (this.container) {
            let {height: l, top: s} = this.container.getBoundingClientRect()
              , u = window.innerHeight - s
              , d = window.innerHeight + l
              , h = u / d
              , c = n + Math.round((h - o) / (a - o) * (r - n));
            i && i(h),
            this.goToAndStop(c, !0),
            (c >= r || h >= a) && this._handleAnimationComplete();
        }
        this._scrollTicking = !1;
    }
    _requestTick(t, e, i) {
        this._scrollTicking || (requestAnimationFrame( () => this._updatePosition(t, e, i)),
        this._scrollTicking = !0);
    }
    playOnScroll(t) {
        this.stop(),
        this._scrollCallback && this.stopPlayOnScroll(),
        this._scrollCallback = () => this._requestTick(t == null ? void 0 : t.segments, t == null ? void 0 : t.threshold, t == null ? void 0 : t.positionCallback),
        window.addEventListener("scroll", this._scrollCallback);
    }
    stopPlayOnScroll() {
        this._scrollCallback && (window.removeEventListener("scroll", this._scrollCallback),
        this._scrollCallback = void 0);
    }
    stopPlayOnShow() {
        this._onShowIntersectionObserver && (this._onShowIntersectionObserver.disconnect(),
        this._onShowIntersectionObserver = void 0);
    }
    addIntersectionObserver(t) {
        if (!this.container)
            throw g("Can't play on show, player container element not available.");
        let e = {
            root: null,
            rootMargin: "0px",
            threshold: t != null && t.threshold ? t.threshold : [0, 1]
        }
          , i = n => {
            n.forEach(r => {
                var o, a;
                this._visibilityPercentage = r.intersectionRatio * 100,
                r.isIntersecting ? (t != null && t.callbackOnIntersect && t.callbackOnIntersect(this._visibilityPercentage),
                (o = this._container) == null || o.dispatchEvent(new Event("visibilityChange"))) : t != null && t.callbackOnIntersect && (t.callbackOnIntersect(0),
                (a = this._container) == null || a.dispatchEvent(new Event("visibilityChange")));
            }
            );
        }
        ;
        this._onShowIntersectionObserver = new IntersectionObserver(i,e),
        this._onShowIntersectionObserver.observe(this.container);
    }
    playOnShow(t) {
        var e;
        if (this.stop(),
        !this.container)
            throw g("Can't play on show, player container element not available.");
        this._onShowIntersectionObserver && this.stopPlayOnShow(),
        this.addIntersectionObserver({
            threshold: (e = t == null ? void 0 : t.threshold) != null ? e : [],
            callbackOnIntersect: i => {
                i === 0 ? this.pause() : this.play();
            }
        });
    }
    _validatePlaybackOptions(t) {
        if (!t)
            return {};
        let e = {};
        for (let[i,n] of Object.entries(t))
            switch (i) {
            case "autoplay":
                typeof n == "boolean" && (e.autoplay = n);
                break;
            case "direction":
                typeof n == "number" && [1, -1].includes(n) && (e.direction = n);
                break;
            case "loop":
                (typeof n == "boolean" || typeof n == "number") && (e.loop = n);
                break;
            case "playMode":
                typeof n == "string" && ["normal", "bounce"].includes(n) && (e.playMode = n);
                break;
            case "speed":
                typeof n == "number" && (e.speed = n);
                break;
            case "themeColor":
                typeof n == "string" && (e.themeColor = n);
                break;
            case "hover":
                typeof n == "boolean" && (e.hover = n);
                break;
            case "intermission":
                typeof n == "number" && (e.intermission = n);
                break;
            case "defaultTheme":
                typeof n == "string" && (e.defaultTheme = n);
                break
            }
        return this._requireValidPlaybackOptions(e),
        e
    }
    _requireAnimationsInTheManifest() {
        var t;
        if (!((t = this._dotLottieLoader.manifest) != null && t.animations.length))
            throw g("No animations found in manifest.")
    }
    _requireAnimationsToBeLoaded() {
        if (this._dotLottieLoader.animationsMap.size === 0)
            throw g("No animations have been loaded.")
    }
    async play(t, e) {
        var i, n;
        if (["initial", "loading"].includes(this._currentState)) {
            k("Player unable to play whilst loading.");
            return
        }
        if (this._requireAnimationsInTheManifest(),
        this._requireAnimationsToBeLoaded(),
        this._lottie && !t) {
            this._lottie.playDirection === -1 && this._lottie.currentFrame === 0 ? this._lottie.goToAndPlay(this._lottie.totalFrames, !0) : this._lottie.play(),
            this.setCurrentState("playing");
            return
        }
        if (typeof t == "number") {
            let r = (i = this._dotLottieLoader.manifest) == null ? void 0 : i.animations[t];
            if (!r)
                throw g("animation not found.");
            typeof e == "function" ? await this.render({
                id: r.id,
                ...e(this._getPlaybackOptions(), this._getOptionsFromAnimation(r))
            }) : await this.render({
                id: r.id
            });
        }
        if (typeof t == "string") {
            let r = (n = this._dotLottieLoader.manifest) == null ? void 0 : n.animations.find(o => o.id === t);
            if (!r)
                throw g("animation not found.");
            typeof e == "function" ? await this.render({
                id: r.id,
                ...e(this._getPlaybackOptions(), this._getOptionsFromAnimation(r))
            }) : await this.render({
                id: r.id
            });
        }
    }
    playSegments(t, e) {
        if (!this._lottie || ["loading"].includes(this._currentState)) {
            k("playSegments() Can't use whilst loading.");
            return
        }
        this._lottie.playSegments(t, e),
        this.setCurrentState("playing");
    }
    resetSegments(t) {
        if (!this._lottie || ["loading"].includes(this._currentState)) {
            k("resetSegments() Can't use whilst loading.");
            return
        }
        this._lottie.resetSegments(t);
    }
    togglePlay() {
        this.currentState === "playing" ? this.pause() : this.play();
    }
    _getAnimationByIdOrIndex(t) {
        var e, i;
        if (this._requireAnimationsInTheManifest(),
        this._requireAnimationsToBeLoaded(),
        typeof t == "number") {
            let n = (e = this._dotLottieLoader.manifest) == null ? void 0 : e.animations[t];
            if (!n)
                throw g("animation not found.");
            return n
        }
        if (typeof t == "string") {
            let n = (i = this._dotLottieLoader.manifest) == null ? void 0 : i.animations.find(r => r.id === t);
            if (!n)
                throw g("animation not found.");
            return n
        }
        throw g("first param must be a number or string")
    }
    get activeAnimationId() {
        return this._getActiveAnimationId()
    }
    get currentAnimationId() {
        return this._currentAnimationId
    }
    get activeStateId() {
        return this._activeStateId
    }
    async _startInteractivity(t) {
        if (!this._inInteractiveMode) {
            et("Can't start interactivity. Not in interactive mode. Call enterInteractiveMode(stateId: string) to start.");
            return
        }
        if (this._dotLottieLoader.stateMachinesMap.size === 0 && await this._dotLottieLoader.getStateMachines(),
        this._dotLottieLoader.stateMachinesMap.size === 0)
            throw g("No interactivity states are available.");
        if (t === "undefined")
            throw g("stateId is not specified.");
        this._stateMachineManager || (this._stateMachineManager = await Ue(Array.from(this._dotLottieLoader.stateMachinesMap.values()), this)),
        this._stateMachineManager.start(t);
    }
    enterInteractiveMode(t) {
        var e;
        if (t)
            this._inInteractiveMode || (this._prevUserPlaybackOptions = {
                ...this._userPlaybackOptions
            }),
            this._inInteractiveMode && ((e = this._stateMachineManager) == null || e.stop()),
            this._activeStateId = t,
            this._inInteractiveMode = !0,
            this._startInteractivity(t);
        else
            throw g("stateId must be a non-empty string.")
    }
    exitInteractiveMode() {
        var t;
        this._inInteractiveMode && (this._inInteractiveMode = !1,
        this._activeStateId = "",
        (t = this._stateMachineManager) == null || t.stop(),
        this._userPlaybackOptions = {},
        this._userPlaybackOptions = {
            ...this._prevUserPlaybackOptions
        },
        this._prevUserPlaybackOptions = {},
        this.reset());
    }
    reset() {
        var t;
        let e = this._getActiveAnimationId()
          , i = (t = this._dotLottieLoader.manifest) == null ? void 0 : t.animations.find(n => n.id === e);
        if (this._inInteractiveMode && this.exitInteractiveMode(),
        !i)
            throw g("animation not found.");
        this.play(e);
    }
    previous(t) {
        if (!this._dotLottieLoader.manifest || !this._dotLottieLoader.manifest.animations.length)
            throw g("manifest not found.");
        if (this._inInteractiveMode) {
            k("previous() is not supported in interactive mode.");
            return
        }
        let e = this._dotLottieLoader.manifest.animations.findIndex(n => n.id === this._currentAnimationId);
        if (e === -1)
            throw g("animation not found.");
        let i = this._dotLottieLoader.manifest.animations[(e - 1 + this._dotLottieLoader.manifest.animations.length) % this._dotLottieLoader.manifest.animations.length];
        if (!i || !i.id)
            throw g("animation not found.");
        typeof t == "function" ? this.render({
            id: i.id,
            ...t(this._getPlaybackOptions(), this._getOptionsFromAnimation(i))
        }) : this.render({
            id: i.id
        });
    }
    next(t) {
        if (!this._dotLottieLoader.manifest || !this._dotLottieLoader.manifest.animations.length)
            throw g("manifest not found.");
        if (this._inInteractiveMode) {
            k("next() is not supported in interactive mode.");
            return
        }
        let e = this._dotLottieLoader.manifest.animations.findIndex(n => n.id === this._currentAnimationId);
        if (e === -1)
            throw g("animation not found.");
        let i = this._dotLottieLoader.manifest.animations[(e + 1) % this._dotLottieLoader.manifest.animations.length];
        if (!i || !i.id)
            throw g("animation not found.");
        typeof t == "function" ? this.render({
            id: i.id,
            ...t(this._getPlaybackOptions(), this._getOptionsFromAnimation(i))
        }) : this.render({
            id: i.id
        });
    }
    getManifest() {
        return this._dotLottieLoader.manifest
    }
    resize() {
        if (!this._lottie || ["loading"].includes(this._currentState)) {
            k("resize() Can't use whilst loading.");
            return
        }
        this._lottie.resize();
    }
    stop() {
        if (!this._lottie || ["loading"].includes(this._currentState)) {
            k("stop() Can't use whilst loading.");
            return
        }
        this.clearCountTimer(),
        this._counter = 0,
        this._setPlayerState( () => ({
            direction: this._getOption("direction")
        })),
        this._lottie.stop(),
        this.setCurrentState("stopped");
    }
    pause() {
        if (!this._lottie || ["loading"].includes(this._currentState)) {
            k("pause() Can't use whilst loading.");
            return
        }
        this.clearCountTimer(),
        this._lottie.pause(),
        this.setCurrentState("paused");
    }
    freeze() {
        if (!this._lottie || ["loading"].includes(this._currentState)) {
            k("freeze() Can't use whilst loading.");
            return
        }
        this.currentState !== "frozen" && (this._stateBeforeFreeze = this.currentState),
        this._lottie.pause(),
        this.setCurrentState("frozen");
    }
    unfreeze() {
        if (!this._lottie || ["loading"].includes(this._currentState)) {
            k("unfreeze() Can't use whilst loading.");
            return
        }
        this._stateBeforeFreeze === "playing" ? this.play() : this.pause();
    }
    destroy() {
        var t, e;
        (t = this._container) != null && t.__lottie && (this._container.__lottie.destroy(),
        this._container.__lottie = null),
        this._audios.length && (this._audios.forEach(i => {
            i.unload();
        }
        ),
        this._audios = []),
        this.clearCountTimer(),
        typeof document < "u" && document.removeEventListener("visibilitychange", () => this._onVisibilityChange()),
        this._counter = 0,
        (e = this._lottie) == null || e.destroy(),
        this._lottie = void 0;
    }
    getAnimationInstance() {
        return this._lottie
    }
    static getLottieWebVersion() {
        return `${Yi.dependencies["lottie-web"]}`
    }
    addEventListener(t, e) {
        var i, n, r;
        this._listeners.has(t) || this._listeners.set(t, new Set),
        (i = this._listeners.get(t)) == null || i.add(e);
        try {
            t === "complete" ? (n = this._container) == null || n.addEventListener(t, e) : (r = this._lottie) == null || r.addEventListener(t, e);
        } catch (o) {
            et(`addEventListener ${o}`);
        }
    }
    getState() {
        var t, e, i, n, r, o, a;
        return {
            autoplay: (e = (t = this._lottie) == null ? void 0 : t.autoplay) != null ? e : !1,
            currentState: this._currentState,
            frame: this._frame,
            visibilityPercentage: this._visibilityPercentage,
            seeker: this._seeker,
            direction: (n = (i = this._lottie) == null ? void 0 : i.playDirection) != null ? n : 1,
            hover: this._hover,
            loop: this._loop || !1,
            playMode: this._mode,
            speed: (o = (r = this._lottie) == null ? void 0 : r.playSpeed) != null ? o : 1,
            background: this._background,
            intermission: this._intermission,
            defaultTheme: this._defaultTheme,
            currentAnimationId: this._currentAnimationId,
            activeStateId: (a = this._activeStateId) != null ? a : ""
        }
    }
    _notify() {
        this.state.setState(this.getState());
    }
    get totalFrames() {
        var t;
        return ((t = this._lottie) == null ? void 0 : t.totalFrames) || 0
    }
    get direction() {
        return this._lottie ? this._lottie.playDirection : 1
    }
    setDirection(t) {
        this._requireValidDirection(t),
        this._setPlayerState( () => ({
            direction: t
        })),
        this._userPlaybackOptions.direction = t;
    }
    get speed() {
        var t;
        return ((t = this._lottie) == null ? void 0 : t.playSpeed) || 1
    }
    setSpeed(t) {
        this._requireValidSpeed(t),
        this._setPlayerState( () => ({
            speed: t
        })),
        this._userPlaybackOptions.speed = t;
    }
    get autoplay() {
        var t, e;
        return (e = (t = this._lottie) == null ? void 0 : t.autoplay) != null ? e : !1
    }
    setAutoplay(t) {
        if (this._requireValidAutoplay(t),
        !this._lottie || ["loading"].includes(this._currentState)) {
            k("setAutoplay() Can't use whilst loading.");
            return
        }
        this._setPlayerState( () => ({
            autoplay: t
        })),
        this._userPlaybackOptions.autoplay = t;
    }
    toggleAutoplay() {
        if (!this._lottie || ["loading"].includes(this._currentState)) {
            k("toggleAutoplay() Can't use whilst loading.");
            return
        }
        this.setAutoplay(!this._lottie.autoplay);
    }
    get defaultTheme() {
        return this._defaultTheme
    }
    setDefaultTheme(t) {
        this._setPlayerState( () => ({
            defaultTheme: t
        })),
        this._userPlaybackOptions.defaultTheme = t,
        this._animation && this.render();
    }
    get loop() {
        return this._loop
    }
    setLoop(t) {
        this._requireValidLoop(t),
        this._setPlayerState( () => ({
            loop: t
        })),
        this._userPlaybackOptions.loop = t;
    }
    toggleLoop() {
        if (!this._lottie || ["loading"].includes(this._currentState)) {
            k("toggleLoop() Can't use whilst loading.");
            return
        }
        this.setLoop(!this._loop);
    }
    get background() {
        return this._background
    }
    setBackground(t) {
        this._requireValidBackground(t),
        this._background = t,
        this._container && (this._container.style.backgroundColor = t);
    }
    get _frame() {
        return this._lottie ? this.currentState === "completed" ? this.direction === -1 ? 0 : this._lottie.totalFrames : this._lottie.currentFrame : 0
    }
    get _seeker() {
        return this._lottie ? this._frame / this._lottie.totalFrames * 100 : 0
    }
    async revertToManifestValues(t) {
        var e;
        let i;
        !Array.isArray(t) || t.length === 0 ? i = ["autoplay", "defaultTheme", "direction", "hover", "intermission", "loop", "playMode", "speed", "activeAnimationId"] : i = t;
        let n = !1;
        if (i.includes("activeAnimationId")) {
            let r = (e = this._dotLottieLoader.manifest) == null ? void 0 : e.activeAnimationId
              , o = this._getAnimationByIdOrIndex(r || 0);
            this._activeAnimationId = r,
            await this._setCurrentAnimation(o.id),
            n = !0;
        }
        i.forEach(r => {
            switch (r) {
            case "autoplay":
                delete this._userPlaybackOptions.autoplay,
                this.setAutoplay(this._getOption("autoplay"));
                break;
            case "defaultTheme":
                delete this._userPlaybackOptions.defaultTheme,
                this.setDefaultTheme(this._getOption("defaultTheme"));
                break;
            case "direction":
                delete this._userPlaybackOptions.direction,
                this.setDirection(this._getOption("direction"));
                break;
            case "hover":
                delete this._userPlaybackOptions.hover,
                this.setHover(this._getOption("hover"));
                break;
            case "intermission":
                delete this._userPlaybackOptions.intermission,
                this.setIntermission(this._getOption("intermission"));
                break;
            case "loop":
                delete this._userPlaybackOptions.loop,
                this.setLoop(this._getOption("loop"));
                break;
            case "playMode":
                delete this._userPlaybackOptions.playMode,
                this.setMode(this._getOption("playMode")),
                this.setDirection(this._getOption("direction"));
                break;
            case "speed":
                delete this._userPlaybackOptions.speed,
                this.setSpeed(this._getOption("speed"));
                break
            }
        }
        ),
        n && this.render();
    }
    removeEventListener(t, e) {
        var i, n, r;
        try {
            t === "complete" ? (i = this._container) == null || i.removeEventListener(t, e) : (n = this._lottie) == null || n.removeEventListener(t, e),
            (r = this._listeners.get(t)) == null || r.delete(e);
        } catch (o) {
            et("removeEventListener", o);
        }
    }
    _handleAnimationComplete() {
        var t;
        typeof this._loop == "number" && this.stop();
        let e = this.direction === -1 ? 0 : this.totalFrames - 1;
        this.goToAndStop(e, !0),
        this._counter = 0,
        this.clearCountTimer(),
        this.setCurrentState("completed"),
        (t = this._container) == null || t.dispatchEvent(new Event("complete"));
    }
    addEventListeners() {
        var t;
        if (!this._lottie || ["loading"].includes(this._currentState)) {
            k("addEventListeners() Can't use whilst loading.");
            return
        }
        this._lottie.addEventListener("enterFrame", () => {
            var e;
            if (!this._lottie) {
                k("enterFrame event : Lottie is undefined.");
                return
            }
            Math.floor(this._lottie.currentFrame) === 0 && this.direction === -1 && ((e = this._container) == null || e.dispatchEvent(new Event("complete")),
            this.loop || this.setCurrentState("completed")),
            this._notify();
        }
        ),
        this._lottie.addEventListener("loopComplete", () => {
            var e;
            if (!this._lottie) {
                k("loopComplete event : Lottie is undefined.");
                return
            }
            (e = this._container) == null || e.dispatchEvent(new Event("loopComplete")),
            this.intermission > 0 && this.pause();
            let i = this._lottie.playDirection;
            if (typeof this._loop == "number" && this._loop > 0 && (this._counter += this._mode === "bounce" ? .5 : 1,
            this._counter >= this._loop)) {
                this._handleAnimationComplete();
                return
            }
            this._mode === "bounce" && typeof i == "number" && (i = Number(i) * -1);
            let n = i === -1 ? this._lottie.totalFrames - 1 : 0;
            this.intermission ? (this.goToAndPlay(n, !0),
            this.pause(),
            this._counterInterval = window.setTimeout( () => {
                this._lottie && (this._setPlayerState( () => ({
                    direction: i
                })),
                this.goToAndPlay(n, !0));
            }
            , this._intermission)) : (this._setPlayerState( () => ({
                direction: i
            })),
            this.goToAndPlay(i === -1 ? this.totalFrames - 1 : 0, !0));
        }
        ),
        this._lottie.addEventListener("complete", () => {
            if (this._lottie && this._loop === !1 && this._mode === "bounce") {
                if (this._counter += .5,
                this._counter >= 1) {
                    this._handleAnimationComplete();
                    return
                }
                this._counterInterval = window.setTimeout( () => {
                    if (!this._lottie)
                        return;
                    let e = this._lottie.playDirection;
                    this._mode === "bounce" && typeof e == "number" && (e = Number(e) * -1);
                    let i = e === -1 ? this.totalFrames - 1 : 0;
                    this._setPlayerState( () => ({
                        direction: e
                    })),
                    this.goToAndPlay(i, !0);
                }
                , this._intermission);
            } else
                this._handleAnimationComplete();
        }
        );
        for (let[e,i] of this._listeners)
            if (e === "complete")
                for (let n of i)
                    (t = this._container) == null || t.addEventListener(e, n);
            else
                for (let n of i)
                    this._lottie.addEventListener(e, n);
    }
    async _setCurrentAnimation(t) {
        this._currentState = "loading";
        let e = await this._dotLottieLoader.getAnimation(t);
        this._currentAnimationId = t,
        this._animation = e,
        this._currentState = "ready";
    }
    async _getAudioFactory() {
        if (this._animation && Ce(this._animation)) {
            let {DotLottieAudio: t} = await import('./dotlottie-audio-75C54RUV.mjs');
            return e => {
                let i = new t({
                    src: [e]
                });
                return this._audios.push(i),
                i
            }
        }
        return null
    }
    async render(t) {
        var e, i, n, r, o, a, l, s, u, d, h, c, p, m, f, v, _, S;
        if (t != null && t.id)
            await this._setCurrentAnimation(t.id);
        else if (!this._animation)
            throw g("no animation selected");
        let y = (e = q.loop) != null ? e : !1
          , A = (i = q.autoplay) != null ? i : !1
          , P = (n = q.playMode) != null ? n : "normal"
          , N = (r = q.intermission) != null ? r : 0
          , O = (o = q.hover) != null ? o : !1
          , I = (a = q.direction) != null ? a : 1
          , T = (l = q.speed) != null ? l : 1
          , B = (s = q.defaultTheme) != null ? s : "";
        y = (u = t == null ? void 0 : t.loop) != null ? u : this._getOption("loop"),
        A = (d = t == null ? void 0 : t.autoplay) != null ? d : this._getOption("autoplay"),
        P = (h = t == null ? void 0 : t.playMode) != null ? h : this._getOption("playMode"),
        N = (c = t == null ? void 0 : t.intermission) != null ? c : this._getOption("intermission"),
        O = (p = t == null ? void 0 : t.hover) != null ? p : this._getOption("hover"),
        I = (m = t == null ? void 0 : t.direction) != null ? m : this._getOption("direction"),
        T = (f = t == null ? void 0 : t.speed) != null ? f : this._getOption("speed"),
        B = (v = t == null ? void 0 : t.defaultTheme) != null ? v : this._getOption("defaultTheme");
        let C = {
            ...this._animationConfig,
            autoplay: O ? !1 : A,
            loop: typeof y == "number" ? !0 : y,
            renderer: this._worker ? "svg" : (_ = this._animationConfig.renderer) != null ? _ : "svg"
        }
          , [z,j,U] = await Promise.all([this._dotLottieLoader.getTheme(B), this._getLottiePlayerInstance(), this._getAudioFactory()]);
        if (z && this._animation ? (this._animation = St(this._animation),
        this._animation.slots = z) : this._animation = await this._dotLottieLoader.getAnimation((S = this._currentAnimationId) != null ? S : ""),
        this._activeStateId && !this._inInteractiveMode) {
            this.enterInteractiveMode(this._activeStateId);
            return
        }
        this.destroy(),
        this._setPlayerState( () => ({
            defaultTheme: B,
            playMode: P,
            intermission: N,
            hover: O,
            loop: y
        })),
        U ? this._lottie = j.loadAnimation({
            ...C,
            container: this._container,
            animationData: this._animation,
            audioFactory: U
        }) : this._lottie = j.loadAnimation({
            ...C,
            container: this._container,
            animationData: this._animation
        }),
        typeof this._lottie.resetSegments > "u" && (this._lottie.resetSegments = () => {
            var E;
            (E = this._lottie) == null || E.playSegments([0, this._lottie.totalFrames], !0);
        }
        ),
        this.addEventListeners(),
        this._container && (this._container.__lottie = this._lottie),
        this._setPlayerState( () => ({
            direction: I,
            speed: T
        })),
        A && !O && (y === !1 && I === -1 ? this.play() : this.setCurrentState("playing")),
        this._updateTestData();
    }
    async _getLottiePlayerInstance() {
        var t;
        let e = (t = this._animationConfig.renderer) != null ? t : "svg", i;
        if (this._worker)
            return e !== "svg" && k("Worker is only supported with svg renderer. Change or remove renderer prop to get rid of this warning."),
            i = await import('./lottie_worker-Q23FJ6ZR-YP5OKMTN.mjs'),
            i.default;
        switch (e) {
        case "svg":
            {
                this._light ? i = await import('./lottie_light-KMJEUZFY-TNG7ODX7.mjs') : i = await import('./lottie_svg-MJGYILXD-NRTSROOT.mjs');
                break
            }
        case "canvas":
            {
                this._light ? i = await import('./lottie_light_canvas-B5UTTNXA-PRI6IBWW.mjs') : i = await import('./lottie_canvas-CDSUBMCL-MZNYH5VV.mjs');
                break
            }
        case "html":
            {
                this._light ? i = await import('./lottie_light_html-SLCECTRT-SYWXEBDN.mjs') : i = await import('./lottie_html-X3TYKVQI-L6774NQS.mjs');
                break
            }
        default:
            throw new Error(`Invalid renderer: ${e}`)
        }
        return i.default
    }
    _getActiveAnimationId() {
        var t, e, i, n;
        let r = this._dotLottieLoader.manifest;
        return (n = (i = (t = this._activeAnimationId) != null ? t : r == null ? void 0 : r.activeAnimationId) != null ? i : (e = r == null ? void 0 : r.animations[0]) == null ? void 0 : e.id) != null ? n : void 0
    }
    async load(t) {
        if (this._currentState === "loading") {
            k("Loading in progress..");
            return
        }
        try {
            if (this.setCurrentState("loading"),
            typeof this._src == "string")
                if (Ee(this._src)) {
                    let i = JSON.parse(this._src);
                    this._dotLottieLoader.loadFromLottieJSON(i);
                } else {
                    let i = new URL(this._src,window.location.href);
                    await this._dotLottieLoader.loadFromUrl(i.toString());
                }
            else if (typeof this._src == "object" && at(this._src))
                this._dotLottieLoader.loadFromLottieJSON(this._src);
            else
                throw g("Invalid src provided");
            if (!this._dotLottieLoader.manifest)
                throw g("No manifest found");
            let e = this._getActiveAnimationId();
            if (!e)
                throw g("No active animation found");
            await this._setCurrentAnimation(e),
            await this.render(t);
        } catch (e) {
            this.setCurrentState("error"),
            e instanceof Error && et(`Error loading animation: ${e.message}`);
        }
    }
    setErrorState(t) {
        this.setCurrentState("error"),
        et(t);
    }
    _requireValidDirection(t) {
        if (t !== -1 && t !== 1)
            throw g("Direction can only be -1 (backwards) or 1 (forwards)")
    }
    _requireValidIntermission(t) {
        if (t < 0 || !Number.isInteger(t))
            throw g("intermission must be a positive number")
    }
    _requireValidLoop(t) {
        if (typeof t == "number" && (!Number.isInteger(t) || t < 0))
            throw g("loop must be a positive number or boolean")
    }
    _requireValidSpeed(t) {
        if (typeof t != "number")
            throw g("speed must be a number")
    }
    _requireValidBackground(t) {
        if (typeof t != "string")
            throw g("background must be a string")
    }
    _requireValidAutoplay(t) {
        if (typeof t != "boolean")
            throw g("autoplay must be a boolean")
    }
    _requireValidPlaybackOptions(t) {
        t.direction && this._requireValidDirection(t.direction),
        t.intermission && this._requireValidIntermission(t.intermission),
        t.loop && this._requireValidLoop(t.loop),
        t.speed && this._requireValidSpeed(t.speed);
    }
}
;

export {g as a, et as b, k as c, rn as d, Zi as e, tn as f, en as g, q as h, nn as i, gn as j};
//# sourceMappingURL=out.js.map
//# sourceMappingURL=chunk-TRZ6EGBZ.mjs.map
