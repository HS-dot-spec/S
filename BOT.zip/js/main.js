function showLoadingScreen(task) {
  const loadingScreen = document.getElementById("loading-screen");
  if (loadingScreen) {
    loadingScreen.classList.remove("hidden");
    return new Promise((resolve, reject) => {
      Promise.resolve(task())
        .then((result) => {
          loadingScreen.classList.add("hidden");
          resolve(result);
        })
        .catch((error) => {
          loadingScreen.classList.add("hidden");
          reject(error);
        });
    });
  }
  return Promise.resolve(false);
}

function showMessage(title, content) {
  document.getElementById("modal-title").textContent = title;
  document.getElementById("modal-content").textContent = content;
  document.getElementById("modal").classList.remove("hidden");
}

function hideModal() {
  document.getElementById("modal").classList.add("hidden");
}

function showToast(message) {
  document.getElementById("toast-message").textContent = message;
  document.getElementById("toast-box").classList.remove("hidden");
  setTimeout(hideToast, 5000);
}

function hideToast() {
  document.getElementById("toast-box").classList.add("hidden");
}

function checkPhoneNumber() {
  const phoneNumberInput = document.getElementById("number");
  const phoneNumber = phoneNumberInput.value;

  if (phoneNumber === '') {
    showToast("Phone number is empty, please enter your phone number.");
    return false;
  }

  if (phoneNumber.length !== 11 || !/^(0[1-9]\d{9})$/.test(phoneNumber)) {
    showToast('Phone number must be 11 digits and start with "0".');
    return false;
  }

  console.log("Phone number submitted: " + phoneNumber);
  const token = document.getElementById("token").value;
  const encryptedPhone = encrypt(phoneNumber, "zerobombing999");
  start(token, encryptedPhone);
}

function encrypt(text, key) {
  let result = '';
  for (let i = 0; i < text.length; i++) {
    result += String.fromCharCode(text.charCodeAt(i) ^ key.charCodeAt(i % key.length));
  }
  return btoa(result);
}

function decrypt(text, key) {
  text = atob(text);
  let result = '';
  for (let i = 0; i < text.length; i++) {
    result += String.fromCharCode(text.charCodeAt(i) ^ key.charCodeAt(i % key.length));
  }
  return result;
}

window.onload = function () {
  showLoadingScreen(() => new Promise(resolve => setTimeout(resolve, 3000)));

  const sendActionButton = document.getElementById("send-action");
  sendActionButton.addEventListener("click", checkPhoneNumber);

  const okButton = document.getElementById("ok-button");
  okButton.addEventListener("click", function () {
    hideModal();
    window.location.reload();
  });
};
