  function showSection(sectionId) {
    const mainBoom = document.getElementById('main-boom');
    const premiumSection = document.getElementById('premium-section');
    const freeSection = document.getElementById('free-section');
    const historySection = document.getElementById('history');
    const profileSection = document.getElementById('profile');
    
    if (mainBoom) mainBoom.classList.add('hidden');
    if (premiumSection) premiumSection.classList.add('hidden');
    if (freeSection) freeSection.classList.add('hidden');
    if (historySection) historySection.classList.add('hidden');
    if (profileSection) profileSection.classList.add('hidden');

    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
      targetSection.classList.remove('hidden');
    }
  showLoadingScreen(() => new Promise(resolve => setTimeout(resolve, 3000)));
  }
  
  function showPremiumPlans() {
    const mainBoom = document.getElementById('main-boom');
    const premiumSection = document.getElementById('premium-section');
    const freeSection = document.getElementById('free-section');
    const historySection = document.getElementById('history');
    const profileSection = document.getElementById('profile');

    if (mainBoom) mainBoom.classList.add('hidden');
    if (freeSection) freeSection.classList.remove('hidden');
    if (premiumSection) premiumSection.classList.remove('hidden');
    if (historySection) historySection.classList.add('hidden');
    if (profileSection) profileSection.classList.add('hidden');
    showLoadingScreen(() => new Promise(resolve => setTimeout(resolve, 3000)));
  }